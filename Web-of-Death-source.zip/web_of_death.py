#!/usr/bin/env python3
"""
Web of Death
Death's Head Software

WYSIWYG HTML editor — KompoZer feature parity in PyQt6 + QtWebEngine.
Design / HTML source tabs per document. No FTP.
Cross-platform: Windows, macOS, Linux.

Requirements:
    pip install PyQt6 PyQt6-WebEngine beautifulsoup4

PyInstaller:
    --collect-all PyQt6.QtWebEngineWidgets
    --collect-all PyQt6.QtWebEngineCore
    --hidden-import PyQt6.QtWebChannel
    macOS: QtWebEngineProcess.app must stay adjacent to the .app bundle.
"""

from __future__ import annotations

import sys
import os
import time
import json
import re
import html as html_module
import tempfile
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, QUrl, pyqtSignal
from PyQt6.QtGui import (
    QColor, QFont, QKeySequence, QPainter, QPixmap, QIcon,
    QSyntaxHighlighter, QTextCharFormat, QAction,
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplashScreen,
    QVBoxLayout, QHBoxLayout, QTabWidget,
    QToolBar, QPushButton, QComboBox, QLabel, QFileDialog,
    QMessageBox, QPlainTextEdit, QDialog,
    QDialogButtonBox, QLineEdit, QSpinBox, QGridLayout,
    QCheckBox, QColorDialog, QStatusBar, QFrame,
    QGroupBox, QRadioButton, QButtonGroup, QTextEdit,
    QSizePolicy, QScrollArea,
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
try:
    from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
    from PyQt6.QtMultimediaWidgets import QVideoWidget
    _MULTIMEDIA_OK = True
except ImportError:
    _MULTIMEDIA_OK = False


# ═══════════════════════════════════════════════════════════════
# Constants & Theme
# ═══════════════════════════════════════════════════════════════

APP_NAME   = "Web of Death"
ORG_NAME   = "Death's Head Software"
VERSION    = "1.0.0"

DARK_BG    = "#1A1A1A"
PANEL_BG   = "#222222"
BORDER     = "#3A3A3A"
ACCENT     = "#8B0000"
TEXT       = "#E0E0E0"
TEXT_DIM   = "#888888"
SOURCE_BG  = "#111111"

CONFIG_PATH = Path.home() / ".web_of_death_config.json"
RECENT_MAX  = 10

STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {DARK_BG}; color: {TEXT};
    font-family: "Segoe UI", "Helvetica Neue", sans-serif; font-size: 9pt;
}}
QMenuBar {{
    background-color: {PANEL_BG}; color: {TEXT}; border-bottom: 1px solid {BORDER};
}}
QMenuBar::item:selected {{ background-color: {ACCENT}; }}
QMenu {{
    background-color: {PANEL_BG}; color: {TEXT}; border: 1px solid {BORDER};
}}
QMenu::item:selected {{ background-color: {ACCENT}; }}
QMenu::separator {{ height: 1px; background: {BORDER}; margin: 4px 8px; }}
QToolBar {{
    background-color: {PANEL_BG}; border-bottom: 1px solid {BORDER};
    spacing: 2px; padding: 3px 6px;
}}
QToolBar QToolButton {{
    background: transparent; color: {TEXT};
    border: 1px solid transparent; border-radius: 3px;
    padding: 6px 10px; font-size: 9pt; min-width: 28px; min-height: 28px;
}}
QToolBar QToolButton:hover {{ background-color: #333333; border-color: {BORDER}; }}
QToolBar QToolButton:pressed {{ background-color: {ACCENT}; }}
QToolBar QComboBox {{
    background-color: #2A2A2A; color: {TEXT}; border: 1px solid {BORDER};
    border-radius: 3px; padding: 3px 6px; max-height: 26px;
}}
QToolBar QComboBox::drop-down {{ border: none; width: 16px; }}
QToolBar QComboBox QAbstractItemView {{
    background-color: #2A2A2A; color: {TEXT};
    selection-background-color: {ACCENT}; border: 1px solid {BORDER};
}}
QTabWidget#doc_tabs::pane {{ border: none; background-color: {DARK_BG}; }}
QTabBar#doc_tab_bar::tab {{
    background-color: {PANEL_BG}; color: {TEXT_DIM};
    border: 1px solid {BORDER}; border-bottom: none;
    padding: 6px 16px; margin-right: 2px;
}}
QTabBar#doc_tab_bar::tab:selected {{
    background-color: {DARK_BG}; color: {TEXT}; border-top: 2px solid {ACCENT};
}}
QTabBar#doc_tab_bar::tab:hover:!selected {{ color: {TEXT}; background-color: #2A2A2A; }}
QTabWidget#view_tabs::pane {{ border: 1px solid {BORDER}; }}
QTabBar#view_tab_bar::tab {{
    background-color: {DARK_BG}; color: {TEXT_DIM};
    border: 1px solid {BORDER}; border-top: none;
    padding: 4px 14px; margin-right: 2px;
    font-family: "Courier New", monospace; font-size: 8pt;
}}
QTabBar#view_tab_bar::tab:selected {{
    background-color: {PANEL_BG}; color: {TEXT};
    border-bottom: 2px solid {ACCENT};
}}
QPlainTextEdit, QTextEdit {{
    background-color: {SOURCE_BG}; color: {TEXT};
    border: none; font-family: "Courier New", monospace; font-size: 13pt;
    selection-background-color: {ACCENT};
}}
QPushButton {{
    background-color: #2D2D2D; color: {TEXT};
    border: 1px solid {BORDER}; border-radius: 3px;
    padding: 7px 14px; min-height: 30px; font-size: 10pt;
}}
QPushButton:hover {{ background-color: #383838; border-color: {ACCENT}; }}
QPushButton:pressed {{ background-color: {ACCENT}; }}
QLineEdit, QSpinBox {{
    background-color: #2A2A2A; color: {TEXT};
    border: 1px solid {BORDER}; border-radius: 3px; padding: 5px 8px;
}}
QLineEdit:focus, QSpinBox:focus {{ border-color: {ACCENT}; }}
QComboBox {{
    background-color: #2A2A2A; color: {TEXT};
    border: 1px solid {BORDER}; border-radius: 3px; padding: 5px 8px;
}}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox QAbstractItemView {{
    background-color: #2A2A2A; color: {TEXT};
    selection-background-color: {ACCENT}; border: 1px solid {BORDER};
}}
QDialog {{ background-color: {PANEL_BG}; }}
QGroupBox {{
    border: 1px solid {BORDER}; border-radius: 3px;
    margin-top: 8px; padding-top: 6px; color: {TEXT_DIM};
}}
QGroupBox::title {{ subcontrol-origin: margin; left: 8px; padding: 0 4px; }}
QLabel {{ color: {TEXT}; }}
QCheckBox {{ color: {TEXT}; spacing: 6px; }}
QRadioButton {{ color: {TEXT}; spacing: 6px; }}
QStatusBar {{
    background-color: {PANEL_BG}; color: {TEXT_DIM};
    border-top: 1px solid {BORDER}; font-size: 8pt;
}}
QFrame#vsep {{ background-color: {BORDER}; max-width: 1px; margin: 4px 4px; }}
"""

# ═══════════════════════════════════════════════════════════════
# Editable document template
# ═══════════════════════════════════════════════════════════════

EDITOR_HTML = """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
  *{box-sizing:border-box;margin:0;padding:0}
  /* html is the grey canvas — body is the white page sitting on it */
  html{background:#d0d0d0;min-height:100%}
  body{
    background:#ffffff;color:#000;
    font-family:Georgia,serif;font-size:14px;line-height:1.6;
    max-width:860px;margin:24px auto;padding:40px 52px;
    min-height:calc(100vh - 48px);
    outline:none;word-wrap:break-word;
    box-shadow:0 2px 8px rgba(0,0,0,0.25);
  }
  a{color:#0055cc} img{max-width:100%}
  table{border-collapse:collapse} td,th{border:1px solid #999;padding:6px 10px}
  th{background:#eee;font-weight:bold}
  pre,code{font-family:"Courier New",monospace;background:#f4f4f4;padding:2px 4px}
  pre{padding:12px;overflow:visible;max-height:none;display:block}
  /* In the editor, override pre background so light-colored text stays visible */
  #editor pre,#editor code{background:#1a1a1a;color:#e0e0e0}
  blockquote{border-left:3px solid #999;padding-left:16px;color:#555;margin:8px 0}
  h1,h2,h3,h4,h5,h6{line-height:1.3;margin:16px 0 8px}
  hr{border:none;border-top:2px solid #666;margin:12px 0}
  .wod-media,img{cursor:pointer;outline-offset:3px}
  .wod-media:focus,img:focus{outline:3px solid #0096FF}
  .wod-media.wod-selected,img.wod-selected{outline:3px solid #0096FF}
</style></head>
<body contenteditable="true" spellcheck="true" id="editor">
<p>Start typing here&hellip;</p>
</body></html>"""

NEW_DOC_HTML = """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Untitled</title></head>
<body><p></p></body></html>"""


# ═══════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════

def resource_path(filename: str) -> Path:
    if getattr(sys, "_MEIPASS", None):
        return Path(sys._MEIPASS) / filename
    here = Path(__file__).parent
    for c in (here / filename, Path(filename)):
        if c.exists():
            return c
    return here / filename


def pretty_html(raw: str) -> str:
    try:
        from bs4 import BeautifulSoup
        return BeautifulSoup(raw, "html.parser").prettify()
    except ImportError:
        return raw


def detect_encoding(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith(b"\xff\xfe"):  return "utf-16"
    if raw.startswith(b"\xef\xbb\xbf"): return "utf-8-sig"
    snip = raw[:2048].decode("latin-1", errors="replace").lower()
    m = re.search(r'charset=["\']?([\w-]+)', snip)
    return m.group(1) if m else "utf-8"


def vsep() -> QFrame:
    f = QFrame(); f.setObjectName("vsep")
    f.setFrameShape(QFrame.Shape.VLine)
    return f


# ═══════════════════════════════════════════════════════════════
# HTML Syntax Highlighter
# ═══════════════════════════════════════════════════════════════

class HtmlHighlighter(QSyntaxHighlighter):
    def __init__(self, parent):
        super().__init__(parent)
        def fmt(c, bold=False):
            f = QTextCharFormat(); f.setForeground(QColor(c))
            if bold: f.setFontWeight(QFont.Weight.Bold)
            return f
        self._rules = [
            (re.compile(r"<[^>]+>"),          fmt("#569CD6")),
            (re.compile(r"</?[\w:]+"),         fmt("#4EC9B0", True)),
            (re.compile(r'\b[\w-]+='),         fmt("#9CDCFE")),
            (re.compile(r'"[^"]*"'),            fmt("#CE9178")),
            (re.compile(r"'[^']*'"),            fmt("#CE9178")),
            (re.compile(r"<!DOCTYPE[^>]*>",re.I), fmt("#C586C0")),
            (re.compile(r"&[\w#]+;"),           fmt("#D7BA7D")),
        ]
        self._cfmt = fmt("#6A9955")
        self._cs = re.compile(r"<!--"); self._ce = re.compile(r"-->")

    def highlightBlock(self, text):
        for p, f in self._rules:
            for m in p.finditer(text): self.setFormat(m.start(), m.end()-m.start(), f)
        self.setCurrentBlockState(0)
        si = 0 if self.previousBlockState() == 1 else -1
        if si == -1:
            m = self._cs.search(text); si = m.start() if m else -1
        while si >= 0:
            me = self._ce.search(text, si)
            if me: ln = me.end()-si; self.setCurrentBlockState(0)
            else:  ln = len(text)-si; self.setCurrentBlockState(1)
            self.setFormat(si, ln, self._cfmt)
            mn = self._cs.search(text, si+ln); si = mn.start() if mn else -1


# ═══════════════════════════════════════════════════════════════
# Editor View
# ═══════════════════════════════════════════════════════════════

class EditorPage(QWebEnginePage):
    def javaScriptConsoleMessage(self, level, msg, line, src): pass

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        # Allow initial page loads (temp file) and reloads
        if nav_type != QWebEnginePage.NavigationType.NavigationTypeLinkClicked:
            return True
        # Open clicked links in the system browser instead of navigating away
        from PyQt6.QtGui import QDesktopServices
        QDesktopServices.openUrl(url)
        return False


class EditorView(QWebEngineView):
    content_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setPage(EditorPage(self))
        s = self.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        self._bg_color = ""   # persists across setHtml() reloads
        self.loadFinished.connect(self._on_load)

    def _on_load(self, ok):
        self.page().runJavaScript(
            "(function(){var b=document.getElementById('editor')||document.body;"
            "b.addEventListener('input',function(){document.title='__chg__';});})()"
        )
        # Click-to-select and Delete/Backspace-to-remove for media & embed elements.
        # Also ensures a visible text caret can land next to non-editable blocks
        # by injecting zero-width spaces around them if missing.
        self.page().runJavaScript(
            "(function(){"
            # -- ensure caret-landable text nodes around every non-editable block --
            # Guard against MutationObserver re-entrancy and duplicate zwsp nodes.
            "var _caretBusy=false;"
            "function ensureCaret(){"
            "  if(_caretBusy)return;"
            "  _caretBusy=true;"
            "  document.querySelectorAll('.wod-media,img').forEach(function(el){"
            "    if(!el.getAttribute('tabindex'))el.setAttribute('tabindex','0');"
            # Only insert zwsp if no text node already precedes/follows
            "    var prev=el.previousSibling;"
            "    if(!prev || (prev.nodeType!==3))"
            "      el.parentNode.insertBefore(document.createTextNode('\\u200B'),el);"
            "    var nxt=el.nextSibling;"
            "    if(!nxt || (nxt.nodeType!==3))"
            "      el.parentNode.insertBefore(document.createTextNode('\\u200B'),el.nextSibling);"
            "  });"
            "  _caretBusy=false;"
            "}"
            "ensureCaret();"
            # -- clear selection outline --
            "function clearSel(){"
            "  document.querySelectorAll('.wod-selected').forEach(function(el){"
            "    el.classList.remove('wod-selected');"
            "  });"
            "}"
            # -- click handler (media AND images, but not iframes so embeds stay interactive) --
            # Use mousedown so we catch clicks before <video> controls swallow them.
            "document.addEventListener('mousedown', function(e){"
            "  var m = e.target.closest ? e.target.closest('.wod-media') : null;"
            "  if(!m && e.target.tagName==='IMG') m=e.target;"
            "  if(m && m.tagName==='IFRAME') m=null;"
            "  clearSel();"
            "  if(m){ m.classList.add('wod-selected'); m.focus(); e.preventDefault(); }"
            "}, true);"
            # -- keyboard handler --
            "document.addEventListener('keydown', function(e){"
            "  if(e.key === 'Delete' || e.key === 'Backspace'){"
            "    var sel = document.querySelector('.wod-selected');"
            "    if(sel){"
            "      e.preventDefault();"
            "      e.stopPropagation();"
            # Select the element into a Range then use execCommand('delete')
            # so it goes on the undo stack and Ctrl+Z works.
            "      var r=document.createRange();"
            "      r.selectNode(sel);"
            "      var s=window.getSelection();"
            "      s.removeAllRanges(); s.addRange(r);"
            "      document.execCommand('delete',false,null);"
            "      document.title = '__chg__';"
            "    }"
            "  } else if(e.key === 'Escape'){"
            "    clearSel();"
            "  }"
            "}, true);"
            # ensureCaret runs once at load (above) and is called explicitly
            # after insert_html.  The MutationObserver was removed because it
            # caused zero-width-space accumulation and layout artifacts.
            "})()"
        )
        # Re-apply stored background color after every page load
        if hasattr(self, '_bg_color') and self._bg_color:
            safe = self._bg_color.replace("'", "\\'")
            self.page().runJavaScript(
                f"document.documentElement.style.backgroundColor='{safe}';"
                f"document.body.style.backgroundColor='{safe}';"
            )

    def load_html(self, content: str, base: Optional[Path] = None):
        """Load user content into the editable template.

        Writes to a temp file and uses load() instead of setHtml() because:
        - setHtml() has a 2 MB size cap
        - setHtml() ignores the baseUrl for security — local images never load
        - load(file://) gives proper origin so relative paths and local files work
        """
        body, body_style = self._extract_body(content)
        tpl  = EDITOR_HTML.replace("<p>Start typing here&hellip;</p>", body or "<p></p>")

        # Re-inject saved background color into the body element
        if body_style:
            tpl = tpl.replace(
                'id="editor">',
                f'id="editor" style="{body_style}">'
            )
            # Also remember the bg color for _on_load re-application
            bg_match = re.search(r'background-color\s*:\s*([^;]+)', body_style)
            if bg_match:
                self._bg_color = bg_match.group(1).strip()

        # If a base path is given, inject a <base href> so the browser
        # resolves relative paths (images/pic.jpg, ../css/style.css)
        # against the original file's directory instead of the temp
        # file's location.
        if base:
            base_dir = base.parent.resolve()
            base_url = QUrl.fromLocalFile(
                base_dir.as_posix() + "/"
            ).toString()
            tpl = tpl.replace(
                "<head>",
                f'<head><base href="{base_url}">',
                1,
            )

        # Write to a named temp file — delete=False so Qt can read it after we close
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".html", encoding="utf-8",
            delete=False, prefix="wod_editor_"
        ) as f:
            f.write(tpl)
            tmp_path = f.name

        # Track temp files for cleanup
        if not hasattr(self, "_tmp_files"):
            self._tmp_files = []
        # Clean up the previous temp file
        for old in self._tmp_files:
            try: os.unlink(old)
            except OSError: pass
        self._tmp_files = [tmp_path]

        self.load(QUrl.fromLocalFile(tmp_path))

    def _extract_body(self, html: str) -> tuple[str, str]:
        """Extract (body_innerHTML, body_style) from a full document.
        body_style contains only background-color to prime the editor on load.
        Returns (fragment, '') if not a full document."""
        low = html.lower()
        if "<body" not in low:
            return html, ""
        body_style = ""
        tag_m = re.search(r"<body([^>]*)>", html, re.IGNORECASE)
        if tag_m:
            s_m = re.search(r'style=["\']([^"\']*)["\']', tag_m.group(1), re.IGNORECASE)
            if s_m:
                bg_m = re.search(r'background-color\s*:\s*([^;]+)', s_m.group(1), re.IGNORECASE)
                if bg_m:
                    body_style = f"background-color:{bg_m.group(1).strip()}"
        content_m = re.search(r"<body[^>]*>(.*)</body>", html, re.DOTALL | re.IGNORECASE)
        if content_m:
            return content_m.group(1).strip(), body_style
        return html, ""
    def get_html(self, cb):
        """Returns body.innerHTML — the user's content only, no implementation artifacts."""
        self.page().runJavaScript(
            "(function(){"
            "var b=document.body;"
            # Remove implementation-only attributes before capturing content
            "b.removeAttribute('data-bg');"
            "b.removeAttribute('data-struct');"
            # Clean up editor-only attributes from images and media
            "b.querySelectorAll('img,[tabindex]').forEach(function(el){"
            "  el.removeAttribute('tabindex');"
            "  el.classList.remove('wod-selected');"
            "});"
            "return b.innerHTML;"
            "})()",
            cb
        )

    def get_bg_color(self, cb):
        """Returns the current body background color as a CSS string, or ''."""
        self.page().runJavaScript(
            "document.body ? document.body.style.backgroundColor : ''",
            cb
        )

    def js(self, code: str):
        self.page().runJavaScript(code)

    def cmd(self, command: str, value: str = ""):
        import json
        v = json.dumps(value)
        # Focus the editor body first so execCommand has a valid selection context
        self.page().runJavaScript(
            "(function(){"
            "  var b = document.getElementById('editor') || document.body;"
            "  b.focus();"
            f"  document.execCommand('{command}', false, {v});"
            "})();"
        )

    def insert_html(self, snippet: str):
        """Insert arbitrary HTML at the cursor.
        Focuses the editor body first — required on macOS where focus returns
        to the Qt window after a dialog closes, leaving execCommand with no target.
        Uses json.dumps for safe encoding of arbitrary paths and characters."""
        import json
        safe = json.dumps(snippet)
        self.setFocus()
        self.page().runJavaScript(
            "(function(){"
            "  var b = document.getElementById('editor') || document.body;"
            "  b.focus();"
            f"  document.execCommand('insertHTML', false, {safe});"
            "  if(typeof ensureCaret==='function') ensureCaret();"
            "})();"
        )

    # ── Formatting ───────────────────────────────────────────
    def bold(self):          self.cmd("bold")
    def italic(self):        self.cmd("italic")
    def underline(self):     self.cmd("underline")
    def strikethrough(self): self.cmd("strikeThrough")
    def superscript(self):   self.cmd("superscript")
    def subscript(self):     self.cmd("subscript")
    def teletype(self):      self.insert_html("<tt>{sel}</tt>".replace("{sel}",""))
    def remove_format(self): self.cmd("removeFormat")
    def remove_links(self):  self.cmd("unlink")

    def align_left(self):
        self.page().runJavaScript(
            "(function(){"
            "var sel=document.querySelector('.wod-selected');"
            "if(sel && (sel.tagName==='IMG'||sel.classList.contains('wod-media'))){"
            "  var p=sel.parentNode;"
            "  if(p.style) p.style.textAlign='left';"
            "  document.title='__chg__';"
            "  return;"
            "}"
            "document.execCommand('justifyLeft');"
            "})()"
        )
    def align_center(self):
        # If an image/media is custom-selected, center it via style;
        # otherwise fall through to normal justifyCenter
        self.page().runJavaScript(
            "(function(){"
            "var sel=document.querySelector('.wod-selected');"
            "if(sel && (sel.tagName==='IMG'||sel.classList.contains('wod-media'))){"
            "  var p=sel.parentNode;"
            "  if(p.style) p.style.textAlign='center';"
            "  document.title='__chg__';"
            "  return;"
            "}"
            "document.execCommand('justifyCenter');"
            "})()"
        )
    def align_right(self):
        self.page().runJavaScript(
            "(function(){"
            "var sel=document.querySelector('.wod-selected');"
            "if(sel && (sel.tagName==='IMG'||sel.classList.contains('wod-media'))){"
            "  var p=sel.parentNode;"
            "  if(p.style) p.style.textAlign='right';"
            "  document.title='__chg__';"
            "  return;"
            "}"
            "document.execCommand('justifyRight');"
            "})()"
        )
    def align_justify(self):
        self.page().runJavaScript(
            "(function(){"
            "var sel=document.querySelector('.wod-selected');"
            "if(sel && (sel.tagName==='IMG'||sel.classList.contains('wod-media'))){"
            "  var p=sel.parentNode;"
            "  if(p.style) p.style.textAlign='justify';"
            "  document.title='__chg__';"
            "  return;"
            "}"
            "document.execCommand('justifyFull');"
            "})()"
        )

    def indent(self):        self.cmd("indent")
    def outdent(self):       self.cmd("outdent")
    def ol(self):            self.cmd("insertOrderedList")
    def ul(self):            self.cmd("insertUnorderedList")

    def block_fmt(self, tag: str): self.cmd("formatBlock", f"<{tag}>")
    def font_face(self, face: str): self.cmd("fontName", face)
    def font_size(self, sz: str):   self.cmd("fontSize", sz)
    def fore_color(self, c: str):
        self.cmd("foreColor", c)
        # Also set text-decoration-color so link underlines match
        safe = c.replace("'", "\\'")
        self.page().runJavaScript(
            "(function(){"
            "var s=window.getSelection();"
            "if(!s||!s.rangeCount)return;"
            "var r=s.getRangeAt(0);"
            "var root=r.commonAncestorContainer;"
            "if(root.nodeType===3)root=root.parentNode;"
            # Find all <a> tags within the selection range
            "var links=root.querySelectorAll?root.querySelectorAll('a'):[];"
            "links.forEach(function(a){"
            "  if(s.containsNode(a,true))"
            f"   {{a.style.color='{safe}';"
            f"   a.style.textDecorationColor='{safe}';}}"
            "});"
            # Also check if the selection is inside an <a>
            "var p=r.startContainer;"
            "while(p&&p!==document.body){"
            "  if(p.nodeType===1&&p.tagName==='A')"
            f"   {{p.style.color='{safe}';"
            f"   p.style.textDecorationColor='{safe}';break;}}"
            "  p=p.parentNode;"
            "}"
            "})()"
        )
    def back_color(self, c: str):
        """Set the page background color, persist it into the DOM so it round-trips
        through save/load, and remember it for reloads."""
        self._bg_color = c
        safe = c.replace("'", "\\'")
        self.js(
            f"document.documentElement.style.backgroundColor='{safe}';"
            f"document.body.style.backgroundColor='{safe}';"
            # Also write it as a data attribute so _extract_body can read it back
            f"document.body.setAttribute('data-bg','{safe}');"
        )
    def span_bg_color(self, c: str): self.cmd("backColor", c)
    def hilite(self, c: str):       self.cmd("hiliteColor", c)
    def insert_hr(self):            self.cmd("insertHorizontalRule")
    def undo(self):                 self.cmd("undo")
    def redo(self):                 self.cmd("redo")
    def cut(self):                  self.cmd("cut")
    def copy(self):                 self.cmd("copy")
    def paste(self):                self.cmd("paste")
    def select_all(self):           self.cmd("selectAll")
    def paste_plain(self):
        self.js(
            "(function(){"
            "var t='';"
            "try{t=event.clipboardData?event.clipboardData.getData('text/plain')"
            ":window.clipboardData.getData('Text');}catch(e){}"
            "document.execCommand('insertText',false,t);})()"
        )
    def _step_font(self, delta: int):
        """Step font size up (delta=+1) or down (delta=-1) using computed px size.
        queryCommandValue('fontSize') is unreliable inside nested <big>/<font> stacks
        so we read the actual computed fontSize from the node at the cursor instead."""
        self.page().runJavaScript(
            "(function(delta){"
            # Bail if no selection
            "  var s=window.getSelection();if(!s||!s.rangeCount)return;"
            # Map px sizes to fontSize levels 1-7 (browser default px for each level)
            "  var PX=[10,13,16,18,24,32,48];"  # approx px for sizes 1-7
            # Get the element at the cursor
            "  var node=s.getRangeAt(0).startContainer;"
            "  if(node.nodeType===3) node=node.parentElement;"
            "  var px=parseFloat(window.getComputedStyle(node).fontSize)||16;"
            # Find nearest level
            "  var best=3,bestDist=9999;"
            "  for(var i=0;i<PX.length;i++){"
            "    var d=Math.abs(PX[i]-px);"
            "    if(d<bestDist){bestDist=d;best=i;}"
            "  }"
            "  var next=Math.max(0,Math.min(6,best+delta));"
            "  document.execCommand('fontSize',false,String(next+1));"
            f"}})({delta})"
        )

    def decrease_font(self):
        self._step_font(-1)

    def increase_font(self):
        self._step_font(1)


# ═══════════════════════════════════════════════════════════════
# Color Swatch Button
# ═══════════════════════════════════════════════════════════════

class ColorSwatchButton(QPushButton):
    color_chosen = pyqtSignal(str)

    def __init__(self, label: str, initial: str, parent=None):
        super().__init__(parent)
        self._color = QColor(initial); self._label = label
        self._apply_fn = None   # optional callable(hex) set by toolbar
        self.setToolTip(label); self.setFixedSize(46, 26)
        self.clicked.connect(self._pick)

    def set_apply(self, fn):
        """Set a callable(hex_str) invoked immediately when color is chosen.
        Using this avoids the editor losing focus before the signal fires."""
        self._apply_fn = fn

    def set_color(self, c: str): self._color = QColor(c); self.update()

    def _pick(self):
        c = QColorDialog.getColor(self._color, self, self._label)
        if c.isValid():
            self._color = c; self.update()
            if self._apply_fn:
                self._apply_fn(c.name())
            self.color_chosen.emit(c.name())

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QColor(BORDER)); p.setBrush(self._color)
        p.drawRoundedRect(3, 3, self.width()-6, self.height()-6, 3, 3)
        p.setPen(QColor("#fff") if self._color.lightness() < 128 else QColor("#000"))
        p.setFont(QFont("Courier New", 7, QFont.Weight.Bold))
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._label[0])
        p.end()


# ═══════════════════════════════════════════════════════════════
# Dialogs
# ═══════════════════════════════════════════════════════════════

class _BaseDialog(QDialog):
    def __init__(self, title: str, w: int, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title); self.setMinimumWidth(w); self.setModal(True)

    def _ok_cancel(self, lay, row, col=0, span=2):
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb, row, col, 1, span)
        return bb


# ── Link ─────────────────────────────────────────────────────

class LinkDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert / Edit Link", 460, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)
        lay.addWidget(QLabel("URL:"), 0, 0)
        self.url  = QLineEdit(); self.url.setPlaceholderText("https://example.com")
        lay.addWidget(self.url, 0, 1)
        lay.addWidget(QLabel("Link text:"), 1, 0)
        self.text = QLineEdit(); self.text.setPlaceholderText("Leave blank to wrap selection")
        lay.addWidget(self.text, 1, 1)
        lay.addWidget(QLabel("Title:"), 2, 0)
        self.title_edit = QLineEdit()
        lay.addWidget(self.title_edit, 2, 1)
        self.new_tab = QCheckBox("Open in new tab (_blank)")
        lay.addWidget(self.new_tab, 3, 1)
        self._ok_cancel(lay, 4)

    @property
    def href(self): return self.url.text().strip()
    @property
    def link_text(self): return self.text.text().strip()
    @property
    def link_title(self): return self.title_edit.text().strip()
    @property
    def target_blank(self): return self.new_tab.isChecked()


# ── Named Anchor ─────────────────────────────────────────────

class AnchorDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert Named Anchor", 340, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)
        lay.addWidget(QLabel("Anchor name:"), 0, 0)
        self.name_edit = QLineEdit()
        lay.addWidget(self.name_edit, 0, 1)
        self._ok_cancel(lay, 1)

    @property
    def anchor_name(self): return self.name_edit.text().strip()


# ── Image ────────────────────────────────────────────────────

class ImageDialog(_BaseDialog):
    # doc_path: Path of the HTML file being edited (None if unsaved).
    # Used to compute relative image paths so saved HTML is portable.
    def __init__(self, parent=None, doc_path=None):
        super().__init__("Insert Image", 500, parent)
        self._doc_path = Path(doc_path) if doc_path else None
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("Source URL / file:"), 0, 0)
        row0 = QHBoxLayout()
        self.src = QLineEdit(); self.src.setPlaceholderText("URL or local path")
        row0.addWidget(self.src)
        b = QPushButton("…"); b.setMaximumWidth(32); b.clicked.connect(self._browse)
        row0.addWidget(b); lay.addLayout(row0, 0, 1)

        lay.addWidget(QLabel("Alt text:"), 1, 0)
        self.alt = QLineEdit(); lay.addWidget(self.alt, 1, 1)

        lay.addWidget(QLabel("Title:"), 2, 0)
        self.img_title = QLineEdit(); lay.addWidget(self.img_title, 2, 1)

        r3 = QHBoxLayout()
        lay.addWidget(QLabel("Width:"), 3, 0)
        self.w_spin = QSpinBox(); self.w_spin.setRange(0, 9999)
        r3.addWidget(self.w_spin); r3.addWidget(QLabel("px  Height:"))
        self.h_spin = QSpinBox(); self.h_spin.setRange(0, 9999)
        r3.addWidget(self.h_spin); r3.addWidget(QLabel("px"))
        r3.addStretch(); lay.addLayout(r3, 3, 1)

        lay.addWidget(QLabel("Border:"), 4, 0)
        r4 = QHBoxLayout()
        self.border_spin = QSpinBox(); self.border_spin.setRange(0, 20)
        r4.addWidget(self.border_spin); r4.addWidget(QLabel("px"))
        r4.addStretch(); lay.addLayout(r4, 4, 1)

        lay.addWidget(QLabel("Align:"), 5, 0)
        self.align_combo = QComboBox()
        for v, l in [("","None"),("center","Center"),("left","Left"),("right","Right"),
                     ("top","Top"),("middle","Middle"),("bottom","Bottom")]:
            self.align_combo.addItem(l, v)
        lay.addWidget(self.align_combo, 5, 1)

        self._ok_cancel(lay, 6)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Image", "",
            "Images (*.png *.jpg *.jpeg *.gif *.webp *.svg);;All (*)")
        if p: self.src.setText(p)

    def build_html(self) -> str:
        raw_src = self.src.text().strip()
        # Local path handling: store a path that works in saved HTML (portable),
        # while still loading in the editor (file:// URI via <base href>).
        if raw_src and not raw_src.startswith(
                ("http://", "https://", "data://", "file://", "//")):
            img_path = Path(raw_src).resolve()
            if self._doc_path:
                # Make the path relative to the document's folder so the saved
                # HTML works on any machine or web server — not tied to this Mac.
                try:
                    rel = img_path.relative_to(self._doc_path.parent)
                    # URL-encode spaces but keep slashes readable
                    from urllib.parse import quote
                    raw_src = quote(str(rel), safe="/")
                except ValueError:
                    # Image is outside the doc folder — use relative path anyway
                    # with ../.. prefix so it still works relatively if possible,
                    # otherwise fall back to just the filename as a last resort.
                    try:
                        import os
                        rel = os.path.relpath(img_path, self._doc_path.parent)
                        from urllib.parse import quote
                        raw_src = quote(rel.replace("\\", "/"), safe="/")
                    except Exception:
                        raw_src = img_path.as_uri()  # absolute file:// only if all else fails
            else:
                # No saved document yet — use file:// so editor can load it;
                # user should re-insert after saving to get a portable path.
                raw_src = img_path.as_uri()
        src  = html_module.escape(raw_src)
        alt  = html_module.escape(self.alt.text().strip())
        t    = html_module.escape(self.img_title.text().strip())
        w    = f' width="{self.w_spin.value()}"'      if self.w_spin.value()          else ""
        h    = f' height="{self.h_spin.value()}"'     if self.h_spin.value()          else ""
        bdr  = f' border="{self.border_spin.value()}"' if self.border_spin.value()    else ""
        align_val = self.align_combo.currentData()
        # "center" is not a valid img align attribute — use a wrapper div
        aln  = f' align="{align_val}"' if align_val and align_val != "center" else ""
        ti   = f' title="{t}"' if t else ""
        tag = f'<img src="{src}" alt="{alt}"{w}{h}{bdr}{aln}{ti}>'
        if align_val == "center":
            return f'<div style="text-align:center">{tag}</div>'
        return tag


# ── Horizontal Rule ──────────────────────────────────────────

class HRDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Horizontal Rule Properties", 360, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("Width:"), 0, 0)
        r0 = QHBoxLayout()
        self.width_spin = QSpinBox(); self.width_spin.setRange(1, 9999); self.width_spin.setValue(100)
        r0.addWidget(self.width_spin)
        self.width_unit = QComboBox()
        self.width_unit.addItems(["%", "px"]); r0.addWidget(self.width_unit); r0.addStretch()
        lay.addLayout(r0, 0, 1)

        lay.addWidget(QLabel("Height (px):"), 1, 0)
        self.height_spin = QSpinBox(); self.height_spin.setRange(1, 50); self.height_spin.setValue(2)
        lay.addWidget(self.height_spin, 1, 1)

        self.shading = QCheckBox("3-D shading"); self.shading.setChecked(True)
        lay.addWidget(self.shading, 2, 0, 1, 2)

        lay.addWidget(QLabel("Align:"), 3, 0)
        self.align = QComboBox(); self.align.addItems(["center","left","right"])
        lay.addWidget(self.align, 3, 1)

        self._ok_cancel(lay, 4)

    def build_html(self) -> str:
        w    = f'{self.width_spin.value()}{self.width_unit.currentText()}'
        h    = self.height_spin.value()
        aln  = self.align.currentText()
        nosh = ' noshade' if not self.shading.isChecked() else ''
        return f'<hr width="{w}" size="{h}" align="{aln}"{nosh}>'


# ── Table ────────────────────────────────────────────────────

class TableDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert Table", 340, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("Rows:"), 0, 0)
        self.rows = QSpinBox(); self.rows.setRange(1, 200); self.rows.setValue(3)
        lay.addWidget(self.rows, 0, 1)

        lay.addWidget(QLabel("Columns:"), 1, 0)
        self.cols = QSpinBox(); self.cols.setRange(1, 50); self.cols.setValue(3)
        lay.addWidget(self.cols, 1, 1)

        lay.addWidget(QLabel("Border (px):"), 2, 0)
        self.border = QSpinBox(); self.border.setRange(0, 20); self.border.setValue(1)
        lay.addWidget(self.border, 2, 1)

        lay.addWidget(QLabel("Spacing (px):"), 3, 0)
        self.spacing = QSpinBox(); self.spacing.setRange(0, 50); self.spacing.setValue(2)
        lay.addWidget(self.spacing, 3, 1)

        lay.addWidget(QLabel("Padding (px):"), 4, 0)
        self.padding = QSpinBox(); self.padding.setRange(0, 50); self.padding.setValue(4)
        lay.addWidget(self.padding, 4, 1)

        lay.addWidget(QLabel("Width:"), 5, 0)
        r5 = QHBoxLayout()
        self.width_spin = QSpinBox(); self.width_spin.setRange(0, 9999); self.width_spin.setValue(100)
        r5.addWidget(self.width_spin)
        self.width_unit = QComboBox(); self.width_unit.addItems(["%","px"])
        r5.addWidget(self.width_unit); r5.addStretch(); lay.addLayout(r5, 5, 1)

        lay.addWidget(QLabel("Align:"), 6, 0)
        self.align = QComboBox(); self.align.addItems(["(none)","left","center","right"])
        lay.addWidget(self.align, 6, 1)

        self.header = QCheckBox("Header row"); self.header.setChecked(True)
        lay.addWidget(self.header, 7, 0, 1, 2)

        self.caption = QCheckBox("Add caption"); lay.addWidget(self.caption, 8, 0, 1, 2)

        self._ok_cancel(lay, 9)

    def build_html(self) -> str:
        r = self.rows.value(); c = self.cols.value()
        bdr  = self.border.value(); sp = self.spacing.value(); pd = self.padding.value()
        w    = f'{self.width_spin.value()}{self.width_unit.currentText()}'
        aln  = self.align.currentText()
        aln_attr = f' align="{aln}"' if aln != "(none)" else ""
        lines = [f'<table border="{bdr}" cellspacing="{sp}" cellpadding="{pd}" width="{w}"{aln_attr}>']
        if self.caption.isChecked():
            lines.append("<caption>Caption</caption>")
        if self.header.isChecked():
            lines.append("<thead><tr>"+"".join(f"<th>Header {i+1}</th>" for i in range(c))+"</tr></thead>")
        lines.append("<tbody>")
        for ri in range(self.header.isChecked(), r):
            lines.append("<tr>"+"".join(f"<td>&nbsp;</td>" for _ in range(c))+"</tr>")
        lines.append("</tbody></table>")
        return "\n".join(lines)


# ── List Properties ──────────────────────────────────────────

class ListDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("List Properties", 360, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("List type:"), 0, 0)
        self.list_type = QComboBox()
        for v, l in [("ul","Unordered (bullet)"),("ol","Ordered (numbered)"),("dl","Definition list")]:
            self.list_type.addItem(l, v)
        self.list_type.currentIndexChanged.connect(self._update_style)
        lay.addWidget(self.list_type, 0, 1)

        lay.addWidget(QLabel("Bullet / number style:"), 1, 0)
        self.style = QComboBox(); lay.addWidget(self.style, 1, 1)

        lay.addWidget(QLabel("Start number:"), 2, 0)
        self.start = QSpinBox(); self.start.setRange(1, 9999); self.start.setValue(1)
        lay.addWidget(self.start, 2, 1)

        self._update_style()
        self._ok_cancel(lay, 3)

    def _update_style(self):
        self.style.clear()
        t = self.list_type.currentData()
        if t == "ul":
            for v, l in [("disc","Disc •"),("circle","Circle ○"),("square","Square ■")]:
                self.style.addItem(l, v)
        elif t == "ol":
            for v, l in [("1","Numbers 1,2,3"),("a","Lowercase a,b,c"),
                         ("A","Uppercase A,B,C"),("i","Lowercase i,ii,iii"),("I","Uppercase I,II,III")]:
                self.style.addItem(l, v)
        self.start.setEnabled(t == "ol")

    def build_html_open(self) -> str:
        t = self.list_type.currentData()
        if t == "dl":
            return "<dl>"
        s = self.style.currentData() or ""
        st = f' type="{s}"' if s else ""
        if t == "ol":
            n = self.start.value()
            sn = f' start="{n}"' if n != 1 else ""
            return f"<ol{st}{sn}>"
        return f"<ul{st}>"


# ── Find & Replace ───────────────────────────────────────────

class FindReplaceDialog(QDialog):
    def __init__(self, editor_view_getter, parent=None):
        super().__init__(parent)
        self._get_editor = editor_view_getter
        self.setWindowTitle("Find & Replace")
        self.setMinimumWidth(420)
        self.setModal(False)   # modeless — KompoZer style

        lay = QGridLayout(self); lay.setSpacing(8); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("Find:"), 0, 0)
        self.find_edit = QLineEdit(); lay.addWidget(self.find_edit, 0, 1)

        lay.addWidget(QLabel("Replace with:"), 1, 0)
        self.replace_edit = QLineEdit(); lay.addWidget(self.replace_edit, 1, 1)

        self.case_cb  = QCheckBox("Case sensitive"); lay.addWidget(self.case_cb, 2, 1)
        self.wrap_cb  = QCheckBox("Wrap search");    self.wrap_cb.setChecked(True)
        lay.addWidget(self.wrap_cb, 3, 1)
        self.back_cb  = QCheckBox("Search backwards"); lay.addWidget(self.back_cb, 4, 1)

        btn_row = QHBoxLayout()
        self.btn_find    = QPushButton("Find Next");      self.btn_find.clicked.connect(self._find_next)
        self.btn_repl    = QPushButton("Replace");        self.btn_repl.clicked.connect(self._replace)
        self.btn_replfnd = QPushButton("Replace & Find"); self.btn_replfnd.clicked.connect(self._replace_find)
        self.btn_replall = QPushButton("Replace All");    self.btn_replall.clicked.connect(self._replace_all)
        self.btn_close   = QPushButton("Close");          self.btn_close.clicked.connect(self.close)
        for b in (self.btn_find, self.btn_repl, self.btn_replfnd, self.btn_replall, self.btn_close):
            btn_row.addWidget(b)
        lay.addLayout(btn_row, 5, 0, 1, 2)

        self.status_lbl = QLabel(""); lay.addWidget(self.status_lbl, 6, 0, 1, 2)

    def _e(self):
        return self._get_editor()

    def _find_next(self):
        e = self._e()
        if not e: return
        needle = self.find_edit.text()
        if not needle: return
        flags = (QWebEnginePage.FindFlag(0)
                 if not self.case_cb.isChecked()
                 else QWebEnginePage.FindFlag.FindCaseSensitively)
        if self.back_cb.isChecked():
            flags |= QWebEnginePage.FindFlag.FindBackward
        def _cb(found):
            self.status_lbl.setText("Found." if found else "Not found.")
        e.page().findText(needle, flags, _cb)

    def _replace(self):
        e = self._e()
        if not e: return
        sel_js = "window.getSelection().toString()"
        needle = self.find_edit.text()
        repl   = self.replace_edit.text()
        def _got_sel(sel):
            cmp = sel if self.case_cb.isChecked() else sel.lower()
            tgt = needle if self.case_cb.isChecked() else needle.lower()
            if cmp == tgt:
                e.cmd("insertText", repl)
        e.page().runJavaScript(sel_js, _got_sel)

    def _replace_find(self):
        self._replace(); self._find_next()

    def _replace_all(self):
        e = self._e()
        if not e: return
        needle = self.find_edit.text()
        repl   = self.replace_edit.text()
        if not needle: return
        flags = "" if self.case_cb.isChecked() else "i"
        safe_needle = needle.replace("'","\\'").replace("/","\\/")
        safe_repl   = repl.replace("'","\\'")
        js = (f"(function(){{"
              f"var b=document.body;"
              f"b.innerHTML=b.innerHTML.replace(new RegExp('{safe_needle}','g{flags}'),'{safe_repl}');"
              f"}})()")
        e.js(js)
        self.status_lbl.setText("Replace All done.")


# ── Insert Special Characters ─────────────────────────────────

SPECIAL_CHARS = [
    ("Accented Upper",  ["À","Á","Â","Ã","Ä","Å","Æ","Ç","È","É","Ê","Ë","Ì","Í","Î","Ï",
                          "Ð","Ñ","Ò","Ó","Ô","Õ","Ö","Ø","Ù","Ú","Û","Ü","Ý","Þ"]),
    ("Accented Lower",  ["à","á","â","ã","ä","å","æ","ç","è","é","ê","ë","ì","í","î","ï",
                          "ð","ñ","ò","ó","ô","õ","ö","ø","ù","ú","û","ü","ý","þ","ÿ"]),
    ("Symbols",         ["©","®","™","°","±","µ","¶","·","¼","½","¾","×","÷","—","–",
                          "…","‹","›","«","»","„",""",""","'","'","•","€","£","¥","¢"]),
    ("Arrows",          ["←","→","↑","↓","↔","⇐","⇒","⇑","⇓","⇔"]),
    ("Math",            ["∞","√","∑","∏","∫","≤","≥","≠","≈","∈","∉","⊂","⊃","∅","∧","∨"]),
]

class InsertCharDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Insert Special Character")
        self.setMinimumWidth(480); self.setModal(True)
        self._chosen = ""

        lay = QVBoxLayout(self); lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        top = QHBoxLayout()
        top.addWidget(QLabel("Category:"))
        self.cat_combo = QComboBox()
        for name, _ in SPECIAL_CHARS: self.cat_combo.addItem(name)
        self.cat_combo.currentIndexChanged.connect(self._populate)
        top.addWidget(self.cat_combo); top.addStretch()
        lay.addLayout(top)

        self._grid_widget = QWidget()
        self._grid = QGridLayout(self._grid_widget)
        self._grid.setSpacing(2)
        scroll = QScrollArea(); scroll.setWidget(self._grid_widget)
        scroll.setWidgetResizable(True); scroll.setFixedHeight(180)
        lay.addWidget(scroll)

        self.preview_lbl = QLabel(""); self.preview_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_lbl.setFont(QFont("serif", 24))
        lay.addWidget(self.preview_lbl)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

        self._populate(0)

    def _populate(self, idx):
        # Clear grid
        for i in reversed(range(self._grid.count())):
            w = self._grid.itemAt(i).widget()
            if w: w.deleteLater()
        chars = SPECIAL_CHARS[idx][1]
        cols = 10
        for n, ch in enumerate(chars):
            b = QPushButton(ch); b.setFixedSize(36, 36)
            b.setFont(QFont("serif", 14))
            b.setToolTip(f"U+{ord(ch):04X}  {ch}")
            b.clicked.connect(lambda _, c=ch: self._select(c))
            self._grid.addWidget(b, n // cols, n % cols)

    def _select(self, ch: str):
        self._chosen = ch; self.preview_lbl.setText(ch)

    @property
    def chosen(self) -> str: return self._chosen


# ── Insert Raw HTML ──────────────────────────────────────────

class InsertHTMLDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert HTML", 500, parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12,12,12,12)
        lay.addWidget(QLabel("Enter HTML to insert at cursor:"))
        self.edit = QPlainTextEdit(); self.edit.setFixedHeight(120)
        lay.addWidget(self.edit)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    @property
    def html(self): return self.edit.toPlainText()


# ── Insert Audio ─────────────────────────────────────────────

class InsertAudioDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert Audio", 480, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        note = QLabel("Local files insert as a playable <audio> element. "
                       "Remote URLs (http/https) insert as a clickable link "
                       "that opens in the browser.")
        note.setStyleSheet(f"color:{TEXT_DIM}; font-size:8pt;")
        note.setWordWrap(True)
        lay.addWidget(note, 0, 0, 1, 2)

        lay.addWidget(QLabel("Audio file / URL:"), 1, 0)
        r0 = QHBoxLayout()
        self.src = QLineEdit(); self.src.setPlaceholderText("File path or URL (.mp3 .ogg .wav .flac .aac)")
        r0.addWidget(self.src)
        b = QPushButton("…"); b.setMaximumWidth(32); b.clicked.connect(self._browse)
        r0.addWidget(b); lay.addLayout(r0, 1, 1)

        self.controls = QCheckBox("Show player controls"); self.controls.setChecked(True)
        lay.addWidget(self.controls, 2, 0, 1, 2)
        self.autoplay = QCheckBox("Autoplay"); lay.addWidget(self.autoplay, 3, 0, 1, 2)
        self.loop     = QCheckBox("Loop");     lay.addWidget(self.loop,     4, 0, 1, 2)
        self.muted    = QCheckBox("Muted");    lay.addWidget(self.muted,    5, 0, 1, 2)

        lay.addWidget(QLabel("Preload:"), 6, 0)
        self.preload = QComboBox()
        self.preload.addItems(["auto", "metadata", "none"])
        lay.addWidget(self.preload, 6, 1)

        self._ok_cancel(lay, 7)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Audio File", "",
            "Audio Files (*.mp3 *.ogg *.wav *.flac *.aac *.m4a *.opus);;All Files (*)")
        if p: self.src.setText(p)

    def build_html(self) -> str:
        raw = self.src.text().strip()
        src = html_module.escape(raw)

        # Remote audio won't play from file:// preview (same-origin policy).
        # Use a styled link like KompoZer does for YouTube — works everywhere.
        if raw.startswith(("http://", "https://")):
            # Extract a display name from the URL
            from urllib.parse import unquote
            name = unquote(raw.rsplit("/", 1)[-1].split("?")[0]) or "Audio"
            safe_name = html_module.escape(name)
            return (
                f'<p style="text-align:center">'
                f'<a href="{src}" target="_blank" '
                f'style="display:inline-block;text-decoration:none;'
                f'background:#1a1a2e;color:#fff;padding:16px 32px;'
                f'border-radius:8px;font-family:sans-serif">'
                f'<span style="font-size:32px;display:block">&#9835;</span>'
                f'<span style="font-size:13px">{safe_name}</span>'
                f'</a></p>')

        ctrl = " controls" if self.controls.isChecked() else ""
        ap   = " autoplay" if self.autoplay.isChecked() else ""
        lp   = " loop"     if self.loop.isChecked()     else ""
        mt   = " muted"    if self.muted.isChecked()    else ""
        pre  = f' preload="{self.preload.currentText()}"'
        return (f'<p style="text-align:center">'
                f'<audio class="wod-media" contenteditable="false" tabindex="0" '
                f'src="{src}"{ctrl}{ap}{lp}{mt}{pre}>'
                f'Your browser does not support the audio element.'
                f'</audio></p>')


# ── Native Video Player ───────────────────────────────────────

class NativeVideoPlayer(QDialog):
    """Full-format video player using OS codecs via QMediaPlayer.
    Supports MP4, MOV, MKV, AVI, WebM, WMV, FLV and anything
    the host OS / GStreamer / DirectShow / QuickTime can decode."""

    def __init__(self, path: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Video Player — Web of Death")
        self.resize(800, 520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        if not _MULTIMEDIA_OK:
            lay.addWidget(QLabel(
                "PyQt6.QtMultimedia is not installed.\n"
                "Run:  pip install --upgrade PyQt6\n"
                "The multimedia modules are included with PyQt6 on macOS and Windows.\n"
                "On Linux you may also need: apt install python3-pyqt6.qtmultimedia"
            ))
            return

        # Video surface
        self._video = QVideoWidget()
        self._video.setMinimumHeight(360)
        lay.addWidget(self._video)

        # Controls row
        ctrl = QHBoxLayout(); ctrl.setContentsMargins(8, 4, 8, 8)
        self._play_btn = QPushButton("▶ Play")
        self._play_btn.setFixedWidth(80)
        self._play_btn.clicked.connect(self._toggle_play)

        self._stop_btn = QPushButton("■ Stop")
        self._stop_btn.setFixedWidth(80)
        self._stop_btn.clicked.connect(self._stop)

        from PyQt6.QtWidgets import QSlider
        self._pos_slider = QSlider(Qt.Orientation.Horizontal)
        self._pos_slider.setRange(0, 1000)
        self._pos_slider.sliderMoved.connect(self._seek)

        self._vol_slider = QSlider(Qt.Orientation.Horizontal)
        self._vol_slider.setRange(0, 100)
        self._vol_slider.setValue(80)
        self._vol_slider.setFixedWidth(90)
        self._vol_slider.setToolTip("Volume")
        self._vol_slider.valueChanged.connect(self._set_vol)

        self._time_lbl = QLabel("0:00 / 0:00")

        open_btn = QPushButton("Open…")
        open_btn.clicked.connect(self._open_file)

        for w in [self._play_btn, self._stop_btn, self._pos_slider,
                  self._time_lbl, QLabel("Vol:"), self._vol_slider, open_btn]:
            ctrl.addWidget(w)
        lay.addLayout(ctrl)

        # Player
        self._player = QMediaPlayer(self)
        self._audio  = QAudioOutput(self)
        self._audio.setVolume(0.8)
        self._player.setAudioOutput(self._audio)
        self._player.setVideoOutput(self._video)
        self._player.playbackStateChanged.connect(self._on_state)
        self._player.positionChanged.connect(self._on_position)
        self._player.durationChanged.connect(self._on_duration)
        self._player.errorOccurred.connect(self._on_error)
        self._duration = 0

        if path:
            self._load(path)

    def _load(self, path: str):
        url = QUrl.fromLocalFile(path) if not path.startswith("http") else QUrl(path)
        self._player.setSource(url)
        self._player.play()

    def _open_file(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "Open Video", "",
            "Video Files (*.mp4 *.m4v *.mov *.mkv *.avi *.wmv *.webm *.ogv *.flv *.3gp);;All Files (*)")
        if p:
            self._load(p)

    def _toggle_play(self):
        if self._player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self._player.pause()
        else:
            self._player.play()

    def _stop(self):
        self._player.stop()

    def _seek(self, val):
        if self._duration:
            self._player.setPosition(int(val / 1000 * self._duration))

    def _set_vol(self, val):
        self._audio.setVolume(val / 100.0)

    def _on_state(self, state):
        playing = state == QMediaPlayer.PlaybackState.PlayingState
        self._play_btn.setText("⏸ Pause" if playing else "▶ Play")

    def _on_position(self, ms):
        if self._duration > 0:
            self._pos_slider.setValue(int(ms / self._duration * 1000))
        self._time_lbl.setText(f"{self._fmt(ms)} / {self._fmt(self._duration)}")

    def _on_duration(self, ms):
        self._duration = ms
        self._time_lbl.setText(f"0:00 / {self._fmt(ms)}")

    def _on_error(self, err, msg):
        QMessageBox.warning(self, "Playback Error",
            f"Could not play the video:\n{msg}\n\n"
            "Make sure the required codec is installed on your system.\n"
            "On Linux: sudo apt install gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly\n"
            "On Windows: install K-Lite Codec Pack or similar\n"
            "On macOS: most formats play natively — try upgrading PyQt6")

    @staticmethod
    def _fmt(ms: int) -> str:
        s = ms // 1000; return f"{s//60}:{s%60:02d}"

    def closeEvent(self, e):
        self._player.stop(); super().closeEvent(e)


# ── Insert Video ─────────────────────────────────────────────

class InsertVideoDialog(_BaseDialog):
    def __init__(self, parent=None):
        super().__init__("Insert Video", 500, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        import sys as _sys
        if _sys.platform == "darwin":
            note_text = ("⚠ macOS: Qt's built-in viewer cannot play MP4/H.264 (no codec licence). "
                         "Use ▶Vid (native player) to preview MP4/MOV. "
                         "WebM plays in the editor. Remote URLs insert as a clickable link.")
        else:
            note_text = ("Local files: MP4/H.264 and WebM in the editor. "
                         "Use ▶Vid for MOV, MKV, AVI. "
                         "Remote URLs (http/https) insert as a clickable link.")
        note = QLabel(note_text)
        note.setStyleSheet(f"color:{TEXT_DIM}; font-size:8pt;")
        note.setWordWrap(True)
        lay.addWidget(note, 0, 0, 1, 2)

        lay.addWidget(QLabel("Video file / URL:"), 1, 0)
        r0 = QHBoxLayout()
        self.src = QLineEdit(); self.src.setPlaceholderText("Local file, YouTube/Vimeo URL, or direct https:// URL")
        r0.addWidget(self.src)
        b = QPushButton("…"); b.setMaximumWidth(32); b.clicked.connect(self._browse_video)
        r0.addWidget(b); lay.addLayout(r0, 1, 1)

        lay.addWidget(QLabel("Poster image:"), 2, 0)
        r1 = QHBoxLayout()
        self.poster = QLineEdit(); self.poster.setPlaceholderText("Optional thumbnail image")
        r1.addWidget(self.poster)
        bp = QPushButton("…"); bp.setMaximumWidth(32); bp.clicked.connect(self._browse_poster)
        r1.addWidget(bp); lay.addLayout(r1, 2, 1)

        r2 = QHBoxLayout()
        lay.addWidget(QLabel("Width:"), 3, 0)
        self.w_spin = QSpinBox(); self.w_spin.setRange(0, 9999); self.w_spin.setValue(640)
        r2.addWidget(self.w_spin); r2.addWidget(QLabel("px  Height:"))
        self.h_spin = QSpinBox(); self.h_spin.setRange(0, 9999); self.h_spin.setValue(360)
        r2.addWidget(self.h_spin); r2.addWidget(QLabel("px"))
        r2.addStretch(); lay.addLayout(r2, 3, 1)

        self.controls = QCheckBox("Show player controls"); self.controls.setChecked(True)
        lay.addWidget(self.controls, 4, 0, 1, 2)
        self.autoplay  = QCheckBox("Autoplay");           lay.addWidget(self.autoplay,  5, 0, 1, 2)
        self.loop      = QCheckBox("Loop");               lay.addWidget(self.loop,      6, 0, 1, 2)
        self.muted     = QCheckBox("Muted");              lay.addWidget(self.muted,     7, 0, 1, 2)
        self.playsinline = QCheckBox("playsinline (mobile)"); lay.addWidget(self.playsinline, 8, 0, 1, 2)

        lay.addWidget(QLabel("Preload:"), 9, 0)
        self.preload = QComboBox()
        self.preload.addItems(["auto", "metadata", "none"])
        lay.addWidget(self.preload, 9, 1)

        self._ok_cancel(lay, 10)

    def _browse_video(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Video File", "",
            "Video Files (*.mp4 *.m4v *.webm *.ogv *.mov *.mkv *.avi *.wmv *.flv *.3gp);;All Files (*)")
        if p: self.src.setText(p)

    def _browse_poster(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Poster Image", "",
            "Images (*.png *.jpg *.jpeg *.gif *.webp);;All Files (*)")
        if p: self.poster.setText(p)

    @staticmethod
    def _youtube_id(url: str) -> Optional[str]:
        """Extract YouTube video ID from various URL formats."""
        m = re.search(
            r'(?:youtube\.com/(?:watch\?.*?v=|embed/|shorts/|v/)|youtu\.be/)'
            r'([A-Za-z0-9_-]{11})', url)
        return m.group(1) if m else None

    @staticmethod
    def _vimeo_id(url: str) -> Optional[str]:
        """Extract Vimeo video ID."""
        m = re.search(r'vimeo\.com/(?:video/)?(\d+)', url)
        return m.group(1) if m else None

    def build_html(self) -> str:
        raw_src = self.src.text().strip()
        w_val = self.w_spin.value() or 640
        h_val = self.h_spin.value() or 360

        # ── YouTube — linked thumbnail image (like KompoZer) ──
        # No iframe embed — just an image that links to the YouTube watch page.
        # Works everywhere: editor, preview, file://, web server.
        yt_id = self._youtube_id(raw_src)
        if yt_id:
            thumb = f"https://img.youtube.com/vi/{yt_id}/hqdefault.jpg"
            watch = f"https://www.youtube.com/watch?v={yt_id}"
            return (f'<a href="{html_module.escape(watch)}" target="_blank">'
                    f'<img src="{html_module.escape(thumb)}" '
                    f'alt="YouTube video" style="border:0" '
                    f'width="{w_val}" height="{h_val}"></a>')

        # ── Vimeo — linked thumbnail image ──
        vim_id = self._vimeo_id(raw_src)
        if vim_id:
            watch = f"https://vimeo.com/{vim_id}"
            # Vimeo has no simple public thumbnail URL, use a styled placeholder
            return (f'<a href="{html_module.escape(watch)}" target="_blank" '
                    f'style="display:inline-block;position:relative;text-decoration:none;'
                    f'background:#1a1a2e;width:{w_val}px;height:{h_val}px">'
                    f'<span style="position:absolute;top:50%;left:50%;'
                    f'transform:translate(-50%,-50%);color:#fff;text-align:center;'
                    f'font-family:sans-serif;pointer-events:none">'
                    f'<span style="font-size:48px;display:block">&#9654;</span>'
                    f'<span style="font-size:14px">Vimeo</span>'
                    f'</span></a>')

        # ── Normal video file ──
        src  = html_module.escape(raw_src)
        w_val = self.w_spin.value() or 640
        h_val = self.h_spin.value() or 360

        # Remote video won't play from file:// preview (same-origin policy).
        # Use a styled link placeholder — like YouTube/Vimeo above.
        if raw_src.startswith(("http://", "https://")):
            from urllib.parse import unquote
            name = unquote(raw_src.rsplit("/", 1)[-1].split("?")[0]) or "Video"
            safe_name = html_module.escape(name)
            return (
                f'<a href="{src}" target="_blank" '
                f'style="display:inline-block;position:relative;text-decoration:none;'
                f'background:#1a1a2e;width:{w_val}px;height:{h_val}px">'
                f'<span style="position:absolute;top:50%;left:50%;'
                f'transform:translate(-50%,-50%);color:#fff;text-align:center;'
                f'font-family:sans-serif;pointer-events:none">'
                f'<span style="font-size:48px;display:block">&#9654;</span>'
                f'<span style="font-size:13px">{safe_name}</span>'
                f'</span></a>')

        raw_post = self.poster.text().strip()
        post = f' poster="{html_module.escape(raw_post)}"' if raw_post else ""
        w    = f' width="{self.w_spin.value()}"'  if self.w_spin.value()  else ""
        h    = f' height="{self.h_spin.value()}"' if self.h_spin.value()  else ""
        ctrl = " controls"    if self.controls.isChecked()    else ""
        ap   = " autoplay"    if self.autoplay.isChecked()    else ""
        lp   = " loop"        if self.loop.isChecked()        else ""
        mt   = " muted"       if self.muted.isChecked()       else ""
        pi   = " playsinline" if self.playsinline.isChecked() else ""
        pre  = f' preload="{self.preload.currentText()}"'
        src_lower = raw_src.lower()
        if src_lower.endswith(".webm"):
            mime = "video/webm"
        elif src_lower.endswith((".ogv", ".ogg")):
            mime = "video/ogg"
        else:
            mime = "video/mp4"
        return (f'<p style="text-align:center">'
                f'<video class="wod-media" contenteditable="false" tabindex="0" '
                f'{w}{h}{post}{ctrl}{ap}{lp}{mt}{pi}{pre}>'
                f'<source src="{src}" type="{mime}">'
                f'Your browser does not support the video element.'
                f'</video></p>')


# ── Page Properties ──────────────────────────────────────────

class PagePropertiesDialog(_BaseDialog):
    def __init__(self, title="", author="", desc="", charset="UTF-8", parent=None):
        super().__init__("Page Properties", 420, parent)
        lay = QGridLayout(self); lay.setSpacing(10); lay.setContentsMargins(16,16,16,16)

        lay.addWidget(QLabel("Title:"), 0, 0)
        self.title_edit = QLineEdit(title); lay.addWidget(self.title_edit, 0, 1)

        lay.addWidget(QLabel("Author:"), 1, 0)
        self.author_edit = QLineEdit(author); lay.addWidget(self.author_edit, 1, 1)

        lay.addWidget(QLabel("Description:"), 2, 0)
        self.desc_edit = QLineEdit(desc); lay.addWidget(self.desc_edit, 2, 1)

        lay.addWidget(QLabel("Charset:"), 3, 0)
        self.charset_edit = QLineEdit(charset); lay.addWidget(self.charset_edit, 3, 1)

        self._ok_cancel(lay, 4)

    @property
    def page_title(self): return self.title_edit.text().strip()
    @property
    def author(self): return self.author_edit.text().strip()
    @property
    def description(self): return self.desc_edit.text().strip()
    @property
    def charset(self): return self.charset_edit.text().strip() or "UTF-8"


# ═══════════════════════════════════════════════════════════════
# Document Widget (one tab = one document)
# ═══════════════════════════════════════════════════════════════

class Document(QWidget):
    modified_changed = pyqtSignal(bool)
    title_changed    = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.file_path: Optional[Path] = None
        self._modified   = False
        self._encoding   = "utf-8"
        self._syncing    = False
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)

        self.view_tabs = QTabWidget()
        self.view_tabs.setObjectName("view_tabs")
        self.view_tabs.tabBar().setObjectName("view_tab_bar")
        self.view_tabs.setTabPosition(QTabWidget.TabPosition.South)

        self.editor  = EditorView()
        self.source  = QPlainTextEdit()
        self.source.setFont(QFont("Courier New", 13))
        self._hl     = HtmlHighlighter(self.source.document())
        self.view_tabs.addTab(self.editor,  "Design")
        self.view_tabs.addTab(self.source,  "HTML")

        # Status bar DOM path (KompoZer "structure bar")
        self.struct_bar = QLabel("")
        self.struct_bar.setStyleSheet(f"background:{PANEL_BG};color:{TEXT_DIM};"
                                       f"border-top:1px solid {BORDER};padding:2px 8px;"
                                       "font-family:'Courier New',monospace;font-size:8pt;")
        self.editor.loadFinished.connect(self._inject_struct_listener)

        lay.addWidget(self.view_tabs)
        lay.addWidget(self.struct_bar)

        self.view_tabs.currentChanged.connect(self._on_view_switch)
        self.editor.load_html(NEW_DOC_HTML)

    def _inject_struct_listener(self, ok):
        js = """
        (function(){
          document.addEventListener('click', function(){
            var n=window.getSelection().anchorNode;
            if(!n)return;
            if(n.nodeType===3)n=n.parentNode;
            var path=[];
            while(n&&n.nodeName!=='BODY'&&n!==document){
              path.unshift(n.nodeName.toLowerCase()); n=n.parentNode;
            }
            document.body.setAttribute('data-struct','body > '+path.join(' > '));
          });
          document.addEventListener('keyup', function(){
            document.body.dispatchEvent(new Event('click'));
          });
        })();
        """
        self.editor.js(js)
        self._poll_struct()

    def _poll_struct(self):
        from PyQt6.QtCore import QTimer
        def _check():
            self.editor.page().runJavaScript(
                "document.body ? (document.body.getAttribute('data-struct')||'body') : 'body'",
                lambda s: self.struct_bar.setText(s or "body")
            )
        t = QTimer(self); t.setInterval(500); t.timeout.connect(_check); t.start()

    def _on_view_switch(self, idx):
        if not hasattr(self, "source"): return
        if self._syncing: return
        self._syncing = True
        if idx == 0:
            # HTML source → Design: source panel holds a full document
            self.editor.load_html(self.source.toPlainText(), self.file_path)
            self._syncing = False
        elif idx == 1:
            # Design → HTML source: show the full clean save document
            def _got(body_html):
                self.editor.get_bg_color(lambda bg: self._finish_source(body_html, bg))
            self.editor.get_html(_got)
    def _finish_source(self, body_html: str, bg: str):
        self._syncing = False
        self.source.setPlainText(pretty_html(self._full_doc(body_html, bg)))

    def get_html_for_save(self, cb):
        """Always produces a clean, standalone HTML5 document."""
        if self.view_tabs.currentIndex() == 1:
            cb(self._ensure_clean_doc(self.source.toPlainText()))
        else:
            def _got_body(body_html):
                # Get background color separately, then build the doc
                self.editor.get_bg_color(lambda bg: cb(self._full_doc(body_html, bg)))
            self.editor.get_html(_got_body)

    def _full_doc(self, body_html: str, bg_color: str = "") -> str:
        """Wrap body innerHTML in a clean HTML5 document.
        bg_color is passed explicitly from get_bg_color() — never inferred from markup."""
        title = self.file_path.stem if self.file_path else "Untitled"
        body_style = f' style="background-color:{bg_color}"' if bg_color else ""
        return (
            f'<!DOCTYPE html>\n<html>\n<head>\n'
            f'<meta charset="{self._encoding.upper()}">\n'
            f'<title>{html_module.escape(title)}</title>\n'
            f'</head>\n<body{body_style}>\n{body_html}\n</body>\n</html>'
        )

    def _ensure_clean_doc(self, html: str) -> str:
        """If the source panel already has a full document, return it as-is.
        If it's just a fragment, wrap it."""
        low = html.lower()
        if "<!doctype" in low or "<html" in low:
            return html
        return self._full_doc(html)

    def load_file(self, path: Path):
        self.file_path = path
        self._encoding = detect_encoding(path)
        try:
            html = path.read_bytes().decode(self._encoding, errors="replace")
        except Exception as e:
            QMessageBox.critical(self.parent(), "Read Error", str(e)); return
        self.editor.load_html(html, path)
        self.source.setPlainText(html)
        self._set_modified(False)
        self.title_changed.emit(path.name)

    def _set_modified(self, v: bool):
        if self._modified != v:
            self._modified = v
            self.modified_changed.emit(v)

    def set_modified(self): self._set_modified(True)

    @property
    def is_modified(self): return self._modified
    @property
    def display_name(self): return self.file_path.name if self.file_path else "Untitled"

    def editor_view(self) -> EditorView: return self.editor

    # ── Page properties async helpers ─────────────────────
    def get_page_title(self, cb): self.editor.page().runJavaScript("document.title", cb)
    def set_page_title(self, t):  self.editor.js(f"document.title='{t.replace(chr(39), chr(92)+chr(39))}'")
    def get_meta(self, name, cb):
        self.editor.page().runJavaScript(
            f"(function(){{var m=document.querySelector('meta[name=\"{name}\"]');"
            f"return m?m.getAttribute('content'):'';}})();", cb)
    def set_meta(self, name, val):
        s = val.replace("'","\\'")
        self.editor.js(
            f"(function(){{var m=document.querySelector('meta[name=\"{name}\"]');"
            f"if(!m){{m=document.createElement('meta');m.name='{name}';"
            f"document.head.appendChild(m);}}m.setAttribute('content','{s}');}})();")


# ═══════════════════════════════════════════════════════════════
# Main Window
# ═══════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._recent: list[str] = []
        self._find_dlg: Optional[FindReplaceDialog] = None
        self._load_cfg()
        self._build_ui()
        self._build_menus()
        self._build_toolbar()
        self._new_doc()

    # ── Config ────────────────────────────────────────────────
    def _load_cfg(self):
        try:
            if CONFIG_PATH.exists():
                d = json.loads(CONFIG_PATH.read_text())
                self._recent = d.get("recent", [])
        except Exception: pass

    def _save_cfg(self):
        try: CONFIG_PATH.write_text(json.dumps({"recent": self._recent}))
        except Exception: pass

    def _add_recent(self, path: Path):
        s = str(path)
        if s in self._recent: self._recent.remove(s)
        self._recent.insert(0, s); self._recent = self._recent[:RECENT_MAX]
        self._save_cfg(); self._rebuild_recent_menu()

    # ── UI shell ──────────────────────────────────────────────
    def _build_ui(self):
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(960, 640); self.resize(1280, 820)
        self.setStyleSheet(STYLESHEET)

        self.doc_tabs = QTabWidget()
        self.doc_tabs.setObjectName("doc_tabs")
        self.doc_tabs.tabBar().setObjectName("doc_tab_bar")
        self.doc_tabs.setTabsClosable(True)
        self.doc_tabs.tabCloseRequested.connect(self._close_tab)
        self.doc_tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.doc_tabs)

        self.status = QStatusBar(); self.setStatusBar(self.status)
        self._status_path = QLabel("")
        self._status_path.setStyleSheet(f"color:{TEXT_DIM};")
        self.status.addPermanentWidget(self._status_path)
        self.status.showMessage("Ready")

    # ── Menu helpers ──────────────────────────────────────────
    def _act(self, label, shortcut, slot, checkable=False) -> QAction:
        a = QAction(label, self)
        if shortcut: a.setShortcut(QKeySequence(shortcut))
        if checkable: a.setCheckable(True)
        a.triggered.connect(slot)
        return a

    # ── Menus — mirrors KompoZer layout ──────────────────────
    def _build_menus(self):
        mb = self.menuBar()

        # ── File ─────────────────────────────────────────────
        fm = mb.addMenu("&File")
        fm.addAction(self._act("&New",            "Ctrl+N",       self._new_doc))
        fm.addAction(self._act("&Open…",          "Ctrl+O",       self._open_file))
        fm.addSeparator()
        fm.addAction(self._act("&Save",           "Ctrl+S",       self._save))
        fm.addAction(self._act("Save &As…",       "Ctrl+Shift+S", self._save_as))
        fm.addAction(self._act("Re&vert",         None,           self._revert))
        fm.addSeparator()
        self._recent_menu = fm.addMenu("Recent Files")
        self._rebuild_recent_menu()
        fm.addSeparator()
        fm.addAction(self._act("&Preview in Browser", "F5",       self._preview_browser))
        fm.addSeparator()
        fm.addAction(self._act("&Close Tab",      "Ctrl+W",
                               lambda: self._close_tab(self.doc_tabs.currentIndex())))
        fm.addAction(self._act("E&xit",           "Ctrl+Q",       self.close))

        # ── Edit ──────────────────────────────────────────────
        em = mb.addMenu("&Edit")
        em.addAction(self._act("&Undo",           "Ctrl+Z",       lambda: self._ec("undo")))
        em.addAction(self._act("&Redo",           "Ctrl+Y",       lambda: self._ec("redo")))
        em.addSeparator()
        em.addAction(self._act("Cu&t",            "Ctrl+X",       lambda: self._ec("cut")))
        em.addAction(self._act("&Copy",           "Ctrl+C",       lambda: self._ec("copy")))
        em.addAction(self._act("&Paste",          "Ctrl+V",       lambda: self._ec("paste")))
        em.addAction(self._act("Paste as Plain Text", "Ctrl+Shift+V", self._paste_plain))
        em.addSeparator()
        em.addAction(self._act("Select &All",     "Ctrl+A",       lambda: self._ec("selectAll")))
        em.addSeparator()
        em.addAction(self._act("&Find & Replace…","Ctrl+H",       self._find_replace))
        em.addSeparator()
        em.addAction(self._act("&Page Properties…",None,          self._page_properties))

        # ── View ──────────────────────────────────────────────
        vm = mb.addMenu("&View")
        vm.addAction(self._act("&Design",         "Ctrl+1",       lambda: self._sv(0)))
        vm.addAction(self._act("&HTML Source",    "Ctrl+2",       lambda: self._sv(1)))

        # ── Format ───────────────────────────────────────────
        fmm = mb.addMenu("F&ormat")

        # Font style submenu — first so Font Face (huge list) doesn't block access
        fst_menu = fmm.addMenu("Font &Style")
        fst_menu.addAction(self._act("&Bold",          "Ctrl+B",   lambda: self._editor() and self._editor().bold()))
        fst_menu.addAction(self._act("&Italic",        "Ctrl+I",   lambda: self._editor() and self._editor().italic()))
        fst_menu.addAction(self._act("&Underline",     "Ctrl+U",   lambda: self._editor() and self._editor().underline()))
        fst_menu.addAction(self._act("S&trikethrough", None,       lambda: self._editor() and self._editor().strikethrough()))
        fst_menu.addAction(self._act("Su&perscript",   None,       lambda: self._editor() and self._editor().superscript()))
        fst_menu.addAction(self._act("S&ubscript",     None,       lambda: self._editor() and self._editor().subscript()))
        fst_menu.addAction(self._act("&Teletype (TT)", "Ctrl+T",   lambda: self._editor() and self._editor().insert_html("<tt></tt>")))

        fmm.addSeparator()
        fmm.addAction(self._act("Text &Color…",              None,  self._pick_text))
        fmm.addAction(self._act("&Background Color (page)…", None, self._pick_bg))
        fmm.addAction(self._act("&Highlight Color (selection)…", None, self._pick_hi))
        fmm.addSeparator()
        fmm.addAction(self._act("Remove &Formatting",  "Ctrl+Space", lambda: self._editor() and self._editor().remove_format()))
        fmm.addAction(self._act("Remove Lin&ks",        None,       lambda: self._editor() and self._editor().remove_links()))
        fmm.addSeparator()

        # Paragraph format submenu
        pf_menu = fmm.addMenu("&Paragraph")
        for tag, label in [("p","Paragraph"),("h1","Heading 1"),("h2","Heading 2"),
                            ("h3","Heading 3"),("h4","Heading 4"),("h5","Heading 5"),
                            ("h6","Heading 6"),("pre","Preformatted"),("blockquote","Block Quote"),
                            ("address","Address"),("dt","Definition Term"),("dd","Definition")]:
            pf_menu.addAction(self._act(label, None,
                (lambda checked, t=tag: self._editor() and self._editor().block_fmt(t))))

        # List submenu
        lst_menu = fmm.addMenu("&List")
        lst_menu.addAction(self._act("&Unordered (Bullet)",  None, lambda: self._editor() and self._editor().ul()))
        lst_menu.addAction(self._act("&Ordered (Numbered)",  None, lambda: self._editor() and self._editor().ol()))
        lst_menu.addAction(self._act("List &Properties…",    None, self._list_properties))
        lst_menu.addSeparator()
        lst_menu.addAction(self._act("&Indent",   "Tab",           lambda: self._editor() and self._editor().indent()))
        lst_menu.addAction(self._act("O&utdent",  "Shift+Tab",     lambda: self._editor() and self._editor().outdent()))

        # Align submenu
        aln_menu = fmm.addMenu("&Align")
        aln_menu.addAction(self._act("&Left",    None, lambda: self._editor() and self._editor().align_left()))
        aln_menu.addAction(self._act("&Center",  None, lambda: self._editor() and self._editor().align_center()))
        aln_menu.addAction(self._act("&Right",   None, lambda: self._editor() and self._editor().align_right()))
        aln_menu.addAction(self._act("&Justify", None, lambda: self._editor() and self._editor().align_justify()))

        fmm.addSeparator()

        # Font size submenu
        fs_menu = fmm.addMenu("Font &Size")
        fs_menu.addAction(self._act("Decrease", "Ctrl+-", lambda: self._editor() and self._editor().decrease_font()))
        fs_menu.addAction(self._act("Increase", "Ctrl+=", lambda: self._editor() and self._editor().increase_font()))
        fs_menu.addSeparator()
        self._fs_actions = {}
        for sz, label in [("1","xx-small"),("2","x-small"),("3","small"),
                           ("4","medium"),("5","large"),("6","x-large"),("7","xx-large")]:
            a = self._act(label, None,
                (lambda checked, s=sz: self._editor() and self._editor().font_size(s)))
            a.setCheckable(True)
            self._fs_actions[sz] = a
            fs_menu.addAction(a)
        fs_menu.aboutToShow.connect(self._update_font_size_checks)

        # Font face submenu — last because it contains hundreds of system fonts
        ff_menu = fmm.addMenu("Font &Face")
        for item in [
            ("", "Variable width (default)"),
            None,
            ("Helvetica, Arial, sans-serif",       "Helvetica / Arial"),
            ("Times New Roman, Times, serif",       "Times New Roman"),
            ("Courier New, Courier, monospace",     "Courier New"),
            ("Georgia, serif",                      "Georgia"),
            ("Verdana, sans-serif",                 "Verdana"),
            ("Trebuchet MS, sans-serif",            "Trebuchet MS"),
            ("Arial Black, Gadget, sans-serif",     "Arial Black"),
            ("Impact, Charcoal, sans-serif",        "Impact"),
            ("Palatino Linotype, Book Antiqua, Palatino, serif", "Palatino"),
            ("Lucida Console, Monaco, monospace",   "Lucida Console"),
        ]:
            if item is None:
                ff_menu.addSeparator()
            else:
                face, label = item
                a = self._act(label, None,
                    (lambda checked, f=face: self._editor() and self._editor().font_face(f)) if face
                    else (lambda checked: self._editor() and self._editor().cmd("removeFormat")))
                ff_menu.addAction(a)
        ff_menu.addSeparator()
        from PyQt6.QtGui import QFontDatabase as _FDB
        for fam in sorted(_FDB.families(), key=str.lower):
            ff_menu.addAction(self._act(
                fam, None,
                (lambda checked, f=fam: self._editor() and self._editor().font_face(f))
            ))

        # ── Insert ────────────────────────────────────────────
        im = mb.addMenu("&Insert")
        im.addAction(self._act("&Link…",              "Ctrl+L",   self._ins_link))
        im.addAction(self._act("Named &Anchor…",      None,       self._ins_anchor))
        im.addAction(self._act("&Image…",             None,       self._ins_image))
        im.addAction(self._act("&Table…",             None,       self._ins_table))
        im.addAction(self._act("Horizontal &Rule…",   None,       self._ins_hr))
        im.addSeparator()
        im.addAction(self._act("&Audio…",             None,       self._ins_audio))
        im.addAction(self._act("&Video…",             None,       self._ins_video))
        im.addAction(self._act("Play Video (Native Player)…", None, self._play_video_native))
        im.addSeparator()
        im.addAction(self._act("Insert &HTML…",       "Ctrl+Shift+H", self._ins_raw_html))
        im.addAction(self._act("Special &Characters…",None,       self._ins_chars))
        im.addSeparator()
        im.addAction(self._act("Line &Break",         "Shift+Return", lambda: self._editor() and self._editor().insert_html("<br>")))
        im.addAction(self._act("Non-breaking &Space", "Ctrl+Shift+Space", lambda: self._editor() and self._editor().insert_html("&nbsp;")))

    def _rebuild_recent_menu(self):
        self._recent_menu.clear()
        for p in self._recent:
            a = QAction(p, self); a.triggered.connect(lambda _, x=p: self._open_path(Path(x)))
            self._recent_menu.addAction(a)
        if not self._recent:
            e = QAction("(none)", self); e.setEnabled(False); self._recent_menu.addAction(e)

    # ── Toolbar ───────────────────────────────────────────────
    def _build_toolbar(self):
        tb = QToolBar("Format"); tb.setMovable(False); self.addToolBar(tb)

        def btn(lbl, tip, slot):
            b = QPushButton(lbl)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            b.setFont(QFont("Segoe UI", 9))
            b.setMinimumHeight(30)
            # Prevent toolbar buttons from stealing focus/selection from the editor
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            # Let width be determined by content — no fixed/minimum width cap
            b.setSizePolicy(
                QSizePolicy.Policy.Minimum,
                QSizePolicy.Policy.Fixed
            )
            b.setStyleSheet(
                f"QPushButton {{ background:#2D2D2D; color:{TEXT}; "
                f"border:1px solid {BORDER}; border-radius:3px; "
                f"padding:4px 8px; font-size:9pt; }}"
                f"QPushButton:hover {{ background:#444; border-color:{ACCENT}; }}"
                f"QPushButton:pressed {{ background:{ACCENT}; }}"
            )
            return b

        # Block format
        self._fmt_combo = QComboBox()
        self._fmt_combo.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._fmt_combo.setMinimumWidth(130)
        for tag, lbl in [("p","Paragraph"),("h1","Heading 1"),("h2","Heading 2"),
                          ("h3","Heading 3"),("h4","Heading 4"),("h5","Heading 5"),
                          ("h6","Heading 6"),("pre","Preformatted"),("blockquote","Block Quote"),
                          ("address","Address")]:
            self._fmt_combo.addItem(lbl, tag)
        self._fmt_combo.currentIndexChanged.connect(
            lambda: self._editor() and self._editor().block_fmt(self._fmt_combo.currentData()))
        tb.addWidget(self._fmt_combo)
        tb.addWidget(vsep())

        # Font face — populated from QFontDatabase (all system fonts)
        self._face_combo = QComboBox()
        self._face_combo.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._face_combo.setMinimumWidth(160)
        self._face_combo.setMaximumWidth(220)
        self._face_combo.addItem("(default)", "")
        self._face_combo.insertSeparator(1)
        # Web-safe stack entries first
        for stack, label in [
            ("Helvetica, Arial, sans-serif",       "Helvetica / Arial"),
            ("Times New Roman, Times, serif",       "Times"),
            ("Courier New, Courier, monospace",     "Courier"),
            ("Georgia, serif",                      "Georgia"),
            ("Verdana, sans-serif",                 "Verdana"),
            ("Trebuchet MS, sans-serif",            "Trebuchet MS"),
            ("Arial Black, Gadget, sans-serif",     "Arial Black"),
            ("Impact, Charcoal, sans-serif",        "Impact"),
            ("Palatino Linotype, Book Antiqua, Palatino, serif", "Palatino"),
            ("Lucida Console, Monaco, monospace",   "Lucida Console"),
            ("Comic Sans MS, cursive",              "Comic Sans MS"),
        ]:
            self._face_combo.addItem(label, stack)
        self._face_combo.insertSeparator(self._face_combo.count())
        # All system fonts
        from PyQt6.QtGui import QFontDatabase
        system_fonts = sorted(set(QFontDatabase.families()), key=str.lower)
        for fam in system_fonts:
            self._face_combo.addItem(fam, fam)
        self._face_combo.currentIndexChanged.connect(self._on_face_change)
        tb.addWidget(self._face_combo)

        # Font size
        self._size_combo = QComboBox()
        self._size_combo.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._size_combo.setMaximumWidth(70)
        for s in ["1","2","3","4","5","6","7"]:
            self._size_combo.addItem({"1":"xx-sm","2":"x-sm","3":"sm","4":"med",
                                       "5":"lg","6":"x-lg","7":"xx-lg"}[s], s)
        self._size_combo.setCurrentIndex(3)
        self._size_combo.currentIndexChanged.connect(
            lambda: self._editor() and self._editor().font_size(self._size_combo.currentData()))
        tb.addWidget(self._size_combo)
        tb.addWidget(btn("A-", "Decrease Font Size", lambda: self._editor() and self._editor().decrease_font()))
        tb.addWidget(btn("A+", "Increase Font Size", lambda: self._editor() and self._editor().increase_font()))
        tb.addWidget(vsep())

        # Style
        tb.addWidget(btn("B",   "Bold (Ctrl+B)",      lambda: self._editor() and self._editor().bold()))
        tb.addWidget(btn("I",   "Italic (Ctrl+I)",    lambda: self._editor() and self._editor().italic()))
        tb.addWidget(btn("U",   "Underline (Ctrl+U)", lambda: self._editor() and self._editor().underline()))
        tb.addWidget(btn("S",   "Strikethrough",      lambda: self._editor() and self._editor().strikethrough()))
        tb.addWidget(btn("Sup", "Superscript",        lambda: self._editor() and self._editor().superscript()))
        tb.addWidget(btn("Sub", "Subscript",          lambda: self._editor() and self._editor().subscript()))
        tb.addWidget(vsep())

        # Color swatches
        self._txt_clr = ColorSwatchButton("Text Color",   "#000000")
        self._bg_clr  = ColorSwatchButton("Page BG",      "#ffffff")
        self._hi_clr  = ColorSwatchButton("Highlight",    "#ffff00")
        self._txt_clr.set_apply(lambda c: self._apply_color("fore",   c))
        self._bg_clr.set_apply( lambda c: self._apply_color("back",   c))
        self._hi_clr.set_apply( lambda c: self._apply_color("hilite", c))
        tb.addWidget(self._txt_clr); tb.addWidget(self._bg_clr); tb.addWidget(self._hi_clr)
        tb.addWidget(vsep())

        # Align
        tb.addWidget(btn("L=",  "Align Left",    lambda: self._editor() and self._editor().align_left()))
        tb.addWidget(btn("=C=", "Align Center",  lambda: self._editor() and self._editor().align_center()))
        tb.addWidget(btn("=R",  "Align Right",   lambda: self._editor() and self._editor().align_right()))
        tb.addWidget(btn("J",   "Justify",       lambda: self._editor() and self._editor().align_justify()))
        tb.addWidget(vsep())

        # Lists
        tb.addWidget(btn("UL",  "Bullet List",   lambda: self._editor() and self._editor().ul()))
        tb.addWidget(btn("OL",  "Numbered List", lambda: self._editor() and self._editor().ol()))
        tb.addWidget(btn(">>",  "Indent",        lambda: self._editor() and self._editor().indent()))
        tb.addWidget(btn("<<",  "Outdent",       lambda: self._editor() and self._editor().outdent()))
        tb.addWidget(vsep())

        # Insert
        tb.addWidget(btn("Lnk", "Insert Link…",   self._ins_link))
        tb.addWidget(btn("Anc", "Insert Anchor…", self._ins_anchor))
        tb.addWidget(btn("Img", "Insert Image…",  self._ins_image))
        tb.addWidget(btn("Aud", "Insert Audio…",      self._ins_audio))
        tb.addWidget(btn("Vid", "Insert Video (HTML)…", self._ins_video))
        tb.addWidget(btn("▶Vid","Play Video (Native)…", self._play_video_native))
        tb.addWidget(btn("Tbl", "Insert Table…",  self._ins_table))
        tb.addWidget(btn("HR",  "Horizontal Rule",self._ins_hr))
        tb.addWidget(vsep())

        # History
        tb.addWidget(btn("<<Z", "Undo (Ctrl+Z)", lambda: self._editor() and self._editor().undo()))
        tb.addWidget(btn("Z>>", "Redo (Ctrl+Y)", lambda: self._editor() and self._editor().redo()))

    def _on_face_change(self):
        e = self._editor()
        if not e: return
        data = self._face_combo.currentData()
        if data is None:
            return          # separator row — ignore
        if data == "":
            e.remove_format()
        else:
            e.font_face(data)

    # ── Current doc / editor accessors ────────────────────────
    def _doc(self) -> Optional[Document]:
        w = self.doc_tabs.currentWidget()
        return w if isinstance(w, Document) else None

    def _editor(self) -> Optional[EditorView]:
        d = self._doc(); return d.editor_view() if d else None

    def _ec(self, cmd: str):
        e = self._editor()
        if e: e.cmd(cmd)

    def _sv(self, idx: int):
        d = self._doc()
        if d: d.view_tabs.setCurrentIndex(idx)

    # ── Tab management ────────────────────────────────────────
    def _new_doc(self):
        doc = Document(self)
        doc.modified_changed.connect(lambda dirty, d=doc: self._on_modified(d, dirty))
        doc.title_changed.connect(lambda t, d=doc: self._set_tab_title(d, t))
        idx = self.doc_tabs.addTab(doc, "Untitled")
        self.doc_tabs.setCurrentIndex(idx)
        self.status.showMessage("New document")

    def _on_tab_changed(self, idx):
        d = self._doc()
        self._status_path.setText(str(d.file_path) if d and d.file_path else "Untitled")

    def _on_modified(self, doc: Document, dirty: bool):
        self._set_tab_title(doc, doc.display_name)

    def _set_tab_title(self, doc: Document, title: str):
        idx = self.doc_tabs.indexOf(doc)
        if idx >= 0:
            self.doc_tabs.setTabText(idx, ("• " if doc.is_modified else "") + title)

    # ── File ops ──────────────────────────────────────────────
    def _open_file(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Open HTML File", "",
            "HTML Files (*.html *.htm *.xhtml);;All Files (*)")
        for p in paths: self._open_path(Path(p))

    def _open_path(self, path: Path):
        for i in range(self.doc_tabs.count()):
            w = self.doc_tabs.widget(i)
            if isinstance(w, Document) and w.file_path == path:
                self.doc_tabs.setCurrentIndex(i); return
        doc = Document(self)
        doc.modified_changed.connect(lambda dirty, d=doc: self._on_modified(d, dirty))
        doc.title_changed.connect(lambda t, d=doc: self._set_tab_title(d, t))
        idx = self.doc_tabs.addTab(doc, path.name)
        self.doc_tabs.setCurrentIndex(idx)
        doc.load_file(path)
        self._add_recent(path)
        self.status.showMessage(f"Opened: {path}")

    def _save(self):
        d = self._doc()
        if not d: return
        if d.file_path: self._save_doc(d, d.file_path)
        else: self._save_as()

    def _save_as(self):
        d = self._doc()
        if not d: return
        p, _ = QFileDialog.getSaveFileName(self, "Save HTML File", "",
            "HTML Files (*.html *.htm);;All Files (*)")
        if p: self._save_doc(d, Path(p))

    def _save_doc(self, doc: Document, path: Path):
        def _do(html):
            try:
                path.write_bytes(html.encode(doc._encoding, errors="replace"))
                doc.file_path = path
                doc._set_modified(False)
                self._add_recent(path); self._set_tab_title(doc, path.name)
                self.status.showMessage(f"Saved: {path}")
            except Exception as e:
                QMessageBox.critical(self, "Save Error", str(e))
        doc.get_html_for_save(_do)

    def _revert(self):
        d = self._doc()
        if d and d.file_path:
            if QMessageBox.question(self, "Revert",
                    f"Discard changes and reload '{d.file_path.name}'?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
               ) == QMessageBox.StandardButton.Yes:
                d.load_file(d.file_path)

    def _close_tab(self, idx: int):
        doc = self.doc_tabs.widget(idx)
        if isinstance(doc, Document) and doc.is_modified:
            r = QMessageBox.question(self, "Unsaved Changes",
                f"'{doc.display_name}' has unsaved changes.\nSave before closing?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.Save)
            if r == QMessageBox.StandardButton.Cancel: return
            if r == QMessageBox.StandardButton.Save:
                self.doc_tabs.setCurrentIndex(idx); self._save()
        self.doc_tabs.removeTab(idx)
        if self.doc_tabs.count() == 0: self._new_doc()

    def _preview_browser(self):
        d = self._doc()
        if not d: return
        import webbrowser
        def _do(html):
            # Inject <base href> so relative images resolve against
            # the original file's directory, not the temp file's.
            if d.file_path:
                base_url = QUrl.fromLocalFile(
                    d.file_path.parent.resolve().as_posix() + "/"
                ).toString()
                base_tag = f'<base href="{base_url}">\n'
                # Case-insensitive insert after <head…>
                m = re.search(r'(<head[^>]*>)', html, re.IGNORECASE)
                if m:
                    pos = m.end()
                    html = html[:pos] + "\n" + base_tag + html[pos:]
            with tempfile.NamedTemporaryFile("w", suffix=".html",
                                             delete=False, encoding="utf-8") as f:
                f.write(html); webbrowser.open("file://" + f.name)
        d.get_html_for_save(_do)

    # ── Insert actions ────────────────────────────────────────
    def _ins_link(self):
        e = self._editor()
        if not e: return
        # Query the selection for an existing <a> OR a selected image
        e.page().runJavaScript(
            "(function(){"
            "var img=document.querySelector('.wod-selected');"
            "if(img && img.tagName==='IMG'){"
            "  var a=img.parentNode;"
            "  if(a && a.tagName==='A')"
            "    return {isImage:true, href:a.getAttribute('href')||'',"
            "      title:a.getAttribute('title')||'',"
            "      target:a.getAttribute('target')||''};"
            "  return {isImage:true};"
            "}"
            "var s=window.getSelection();"
            "if(!s||!s.rangeCount)return null;"
            "var n=s.anchorNode;"
            "if(n.nodeType===3)n=n.parentNode;"
            "while(n&&n.tagName!=='A')n=n.parentNode;"
            "if(!n)return null;"
            "return {href:n.getAttribute('href')||'',"
            "title:n.getAttribute('title')||'',"
            "target:n.getAttribute('target')||''};"
            "})()",
            lambda info: self._open_link_dialog(e, info)
        )

    def _open_link_dialog(self, e, existing_info):
        is_image = existing_info and existing_info.get("isImage")
        dlg = LinkDialog(self)
        if existing_info:
            dlg.url.setText(existing_info.get("href", ""))
            dlg.title_edit.setText(existing_info.get("title", ""))
            if existing_info.get("target", "").lower() == "_blank":
                dlg.new_tab.setChecked(True)
        if dlg.exec() != QDialog.DialogCode.Accepted or not dlg.href: return

        # ── Image link: wrap the selected image in <a> via JS ──
        if is_image:
            safe_href = dlg.href.replace("\\", "\\\\").replace("'", "\\'")
            tgt = "'_blank'" if dlg.target_blank else "null"
            ttl = "'" + dlg.link_title.replace("\\", "\\\\").replace("'", "\\'") + "'" if dlg.link_title else "null"
            e.page().runJavaScript(
                "(function(){"
                "var img=document.querySelector('.wod-selected');"
                "if(!img||img.tagName!=='IMG')return;"
                "var existing=img.parentNode;"
                "if(existing&&existing.tagName==='A'){"
                f"  existing.setAttribute('href','{safe_href}');"
                f"  if({tgt})existing.setAttribute('target',{tgt});else existing.removeAttribute('target');"
                f"  if({ttl})existing.setAttribute('title',{ttl});else existing.removeAttribute('title');"
                "}else{"
                "  var a=document.createElement('a');"
                f"  a.setAttribute('href','{safe_href}');"
                f"  if({tgt})a.setAttribute('target',{tgt});"
                f"  if({ttl})a.setAttribute('title',{ttl});"
                "  img.parentNode.insertBefore(a,img);"
                "  a.appendChild(img);"
                "}"
                "document.title='__chg__';"
                "})()"
            )
            return

        target = ' target="_blank"' if dlg.target_blank else ""
        title  = f' title="{html_module.escape(dlg.link_title)}"' if dlg.link_title else ""
        if dlg.link_text:
            e.insert_html(f'<a href="{html_module.escape(dlg.href)}"{target}{title}>'
                          f'{html_module.escape(dlg.link_text)}</a>')
        else:
            # createLink wraps the selection in <a> but ignores target/title
            # and forces browser-default blue.  Do everything in one JS call
            # so the selection stays intact: capture color → createLink →
            # walk up to the new <a> → apply target/title/color.
            safe_href = dlg.href.replace("\\", "\\\\").replace("'", "\\'")
            post = ""
            if dlg.target_blank:
                post += "a.setAttribute('target','_blank');"
            else:
                post += "a.removeAttribute('target');"
            if dlg.link_title:
                safe_t = dlg.link_title.replace("\\", "\\\\").replace("'", "\\'")
                post += f"a.setAttribute('title','{safe_t}');"
            else:
                post += "a.removeAttribute('title');"
            e.page().runJavaScript(
                "(function(){"
                "var s=window.getSelection();"
                "if(!s||!s.rangeCount)return;"
                # capture current text color before createLink changes it
                "var node=s.anchorNode;"
                "if(node.nodeType===3)node=node.parentNode;"
                "var clr=window.getComputedStyle(node).color;"
                # createLink in the same JS execution context
                f"document.execCommand('createLink',false,'{safe_href}');"
                # walk from selection up to the <a> that was just created
                "s=window.getSelection();"
                "if(!s||!s.rangeCount)return;"
                "var n=s.anchorNode;"
                "while(n&&n.tagName!=='A')n=n.parentNode;"
                "if(!n)return;var a=n;"
                # restore original text color and underline color
                "if(clr){a.style.color=clr;a.style.textDecorationColor=clr;}"
                + post +
                "})()"
            )

    def _ins_anchor(self):
        e = self._editor()
        if not e: return
        dlg = AnchorDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted or not dlg.anchor_name: return
        e.insert_html(f'<a name="{html_module.escape(dlg.anchor_name)}"></a>')

    def _ins_image(self):
        e = self._editor()
        if not e: return
        doc = self._doc()
        doc_path = doc.file_path if doc else None
        dlg = ImageDialog(self, doc_path=doc_path)
        if dlg.exec() != QDialog.DialogCode.Accepted or not dlg.src.text().strip(): return
        e.insert_html(dlg.build_html())

    def _ins_table(self):
        e = self._editor()
        if not e: return
        dlg = TableDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            e.insert_html(dlg.build_html())

    def _ins_hr(self):
        e = self._editor()
        if not e: return
        dlg = HRDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            e.insert_html(dlg.build_html())
        else:
            e.insert_hr()

    def _ins_raw_html(self):
        e = self._editor()
        if not e: return
        dlg = InsertHTMLDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.html.strip():
            e.insert_html(dlg.html)

    def _ins_chars(self):
        e = self._editor()
        if not e: return
        dlg = InsertCharDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.chosen:
            e.insert_html(dlg.chosen)

    def _list_properties(self):
        e = self._editor()
        if not e: return
        dlg = ListDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            tag = dlg.list_type.currentData()
            if tag == "ul": e.ul()
            elif tag == "ol": e.ol()

    # ── Color actions ─────────────────────────────────────────

    def _apply_color(self, kind: str, hex_color: str):
        """Called directly from ColorSwatchButton before dialog closes,
        so the editor reference is captured while the document tab is still active."""
        e = self._editor()
        if not e: return
        if kind == "fore":   e.fore_color(hex_color)
        elif kind == "back": e.back_color(hex_color)
        elif kind == "hilite": e.hilite(hex_color)

    def _update_font_size_checks(self):
        """Query the editor's current fontSize and check the matching menu item."""
        e = self._editor()
        if not e:
            return
        def _got_size(val):
            # document.queryCommandValue('fontSize') returns "1"–"7" or ""
            for sz, act in self._fs_actions.items():
                act.setChecked(sz == str(val).strip())
        e.page().runJavaScript(
            "document.queryCommandValue('fontSize')", _got_size)

    def _pick_text(self): self._txt_clr.click()
    def _pick_bg(self):   self._bg_clr.click()
    def _pick_hi(self):   self._hi_clr.click()

    # ── Audio / Video ──────────────────────────────────────────

    @staticmethod
    def _path_to_url(p: str) -> str:
        """Return a file:// URL for a local path; leave http/https/data as-is."""
        if not p or p.startswith(("http://","https://","file://","data:")):
            return p
        return Path(p).resolve().as_uri()

    def _ins_audio(self):
        e = self._editor()
        if not e: return
        dlg = InsertAudioDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.src.text().strip():
            # Store file:// URL so both the live editor AND Firefox can play it
            original = dlg.src.text().strip()
            dlg.src.setText(self._path_to_url(original))
            e.insert_html(dlg.build_html())

    def _ins_video(self):
        e = self._editor()
        if not e: return
        dlg = InsertVideoDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.src.text().strip():
            raw_src = dlg.src.text().strip()
            is_embed = (InsertVideoDialog._youtube_id(raw_src) is not None
                        or InsertVideoDialog._vimeo_id(raw_src) is not None)
            if not is_embed:
                # Convert local path → file:// URL so the browser can resolve it
                dlg.src.setText(self._path_to_url(raw_src))
                if dlg.poster.text().strip():
                    dlg.poster.setText(self._path_to_url(dlg.poster.text().strip()))
            e.insert_html(dlg.build_html())
            # On macOS the QtWebEngine build ships without the H.264 patent licence,
            # so MP4 will not play in the editor canvas. Offer the native player.
            src = dlg.src.text().strip()
            is_mp4 = src.lower().endswith((".mp4", ".m4v", ".mov"))
            if is_mp4 and sys.platform == "darwin":
                r = QMessageBox.information(self, "Video Inserted",
                    "The video tag has been inserted into the page.\n\n"
                    "Note: the built-in editor view cannot play MP4/H.264 on macOS "
                    "because Qt ships without the H.264 codec licence.\n\n"
                    "Use the ▶Vid button (or Insert → Play Video) to preview "
                    "using the native macOS player, which supports all formats.",
                    QMessageBox.StandardButton.Ok)
            elif is_mp4:
                # On Windows/Linux offer to open native player too
                r = QMessageBox.question(self, "Video Inserted",
                    "Video tag inserted.\n\nOpen in native player now to preview?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                if r == QMessageBox.StandardButton.Yes:
                    player = NativeVideoPlayer(src, self)
                    player.show()

    def _play_video_native(self):
        """Open the native OS video player popup — plays any format the OS supports."""
        p, _ = QFileDialog.getOpenFileName(
            self, "Open Video in Native Player", "",
            "Video Files (*.mp4 *.m4v *.mov *.mkv *.avi *.wmv *.webm *.ogv *.flv *.3gp);;All Files (*)")
        if p:
            player = NativeVideoPlayer(p, self)
            player.show()

    # ── Edit actions ──────────────────────────────────────────
    def _paste_plain(self):
        from PyQt6.QtGui import QGuiApplication
        cb = QGuiApplication.clipboard()
        text = cb.text()
        e = self._editor()
        if e and text:
            e.cmd("insertText", text)

    def _find_replace(self):
        if self._find_dlg is None or not self._find_dlg.isVisible():
            self._find_dlg = FindReplaceDialog(self._editor, self)
        self._find_dlg.show(); self._find_dlg.raise_()
        self._find_dlg.find_edit.setFocus()

    # ── Page Properties ───────────────────────────────────────
    def _page_properties(self):
        d = self._doc()
        if not d: return
        def _got_desc(desc):
            def _got_author(author):
                def _got_title(title):
                    dlg = PagePropertiesDialog(title or "", author or "", desc or "",
                                               d._encoding.upper(), self)
                    if dlg.exec() != QDialog.DialogCode.Accepted: return
                    d.set_page_title(dlg.page_title)
                    d.set_meta("author", dlg.author)
                    d.set_meta("description", dlg.description)
                    d._encoding = dlg.charset.lower()
                    d.set_modified()
                d.get_page_title(_got_title)
            d.get_meta("author", _got_author)
        d.get_meta("description", _got_desc)

    # ── Close ─────────────────────────────────────────────────
    def closeEvent(self, event):
        for i in range(self.doc_tabs.count()):
            doc = self.doc_tabs.widget(i)
            if isinstance(doc, Document) and doc.is_modified:
                self.doc_tabs.setCurrentIndex(i)
                r = QMessageBox.question(self, "Unsaved Changes",
                    f"'{doc.display_name}' has unsaved changes. Discard and exit?",
                    QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                    QMessageBox.StandardButton.Cancel)
                if r == QMessageBox.StandardButton.Cancel:
                    event.ignore(); return
        self._save_cfg(); event.accept()


# ═══════════════════════════════════════════════════════════════
# Splash Screen  (standard Death's Head Software pattern)
# ═══════════════════════════════════════════════════════════════

def create_splash() -> Optional[QSplashScreen]:
    try:
        splash_path = resource_path("splash.png")
        W, H = 800, 600

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(W, H); pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != W or pixmap.height() != H:
                pixmap = pixmap.scaled(W, H, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        else:
            pixmap = QPixmap(W, H); pixmap.fill(QColor(20, 20, 20))

        painter = QPainter(pixmap)

        # App name — white
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier New", 38, QFont.Weight.Bold))
        r = pixmap.rect(); r.setTop(28); r.setBottom(88)
        painter.drawText(r, Qt.AlignmentFlag.AlignCenter, APP_NAME)

        # ASCII skull (fallback only)
        if not splash_path.exists():
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier New", 14))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull):
                painter.drawText(250, 230 + i * 25, line)

        # Org name — white
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier New", 14, QFont.Weight.Bold))
        fr = pixmap.rect(); fr.setTop(H - 100); fr.setBottom(H - 50)
        painter.drawText(fr, Qt.AlignmentFlag.AlignCenter, ORG_NAME)

        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print(f"Splash error: {e}"); return None


# ═══════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════

SPLASH_MSGS = [
    "Loading Chromium engine…",
    "Initialising DOM…",
    "Building editor surface…",
    "Mounting stylesheet…",
    "Ready.",
]

def main():
    if sys.platform.startswith("linux"):
        os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    # Application/taskbar icon. Keep icon.ico beside the script or bundled
    # at the application root; resource_path() handles both cases.
    icon_path = resource_path("icon.ico")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    splash = create_splash()
    if splash:
        splash.show()
        splash.raise_()
        splash.activateWindow()
        for msg in SPLASH_MSGS:
            splash.showMessage("\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255))
            app.processEvents()
            time.sleep(1.08)

    try:
        win = MainWindow()
        for arg in sys.argv[1:]:
            p = Path(arg)
            if p.is_file() and p.suffix.lower() in (".html", ".htm", ".xhtml"):
                win._open_path(p)
        win.show()
        if splash: splash.finish(win)
        sys.exit(app.exec())
    except Exception:
        import traceback
        tb = traceback.format_exc()
        print(tb, file=sys.stderr)
        QMessageBox.critical(None, "Startup Error", tb)
        sys.exit(1)

if __name__ == "__main__":
    main()
